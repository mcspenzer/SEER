Reminders:

    -Before starting, extract mo muna lahat ng files sa zip na to sa htdocs folder mo saka ka mag work.

    -Import mo yung 127_0_0_1.sql file para may initial data ka na to work and experiment on sa Database

    -I recommend na aralin mo muna yung flow nung System once more dun sa 'seer_v2_frontend' kasi wala pa namang backend yun. Kumbaga  refresher course ganon para marecall mo or maging aware ka sa new layout and changes sa new system natin.

    -If magstastart ka na on the logic part, gawin mo lang basis yung 'seer_v2_backend' kasi nandun lahat ng controller files. When I say controller files, sila na naghahandle lahat ng logic and output. specifically sa 'seer_v2_backend/includes' directory. Intuitive naman lahat ng filenames. 
    
    Example:                                      
        'seer_addStudent.inc.php'           //used for adding a student in the database
        'seer_changePassword.inc.php'       //used for changing the current logged-in user's password
        'seer_logout.inc.php'               //used for logging the user output
            .............
             ...........
              .........
               .......
                .....
                 ...
                  .
             and so on
    
    -basahin lahat ng comments to know the system and the controllers better. Naka annotate naman lahat ng controller files for your convenience para alam mo para san tong variable na to, or ano ba tong function na to, or what. If deins mo parin magets, chat mo lang me if ever, or pag di me online, text/ call me. I'll respond whenever I can.

    -If legit na magstastart ka na to code backend, dun ka na magwork sa 'seer_v2_frontend' kasi andun na yung latest layout nung System natin and para di narin hassle mag merge ng code from the old version to the new one, which I am doing as you're reading this instructions.

Tasks:

Accounts Page
    -Delete 
        self explanatory naman na sya. Basta pag clinick ng user yung edit icon beside the name of the user tapos pag clinick na nya yung terminate user, madedelete na after maenter yung password.

    -Modify User
        Change the user's account type. Once na naenter na yung password, dapat maging admin/ faculty na yung user, depending on the action of the administrator; kung ano yung sinet nya na account type.

#ReadyForDeployment