<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Final</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:400,700">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Abril+Fatface">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
    <link rel="stylesheet" href="assets/css/Data-Table.css">
    <link rel="stylesheet" href="assets/css/Data-Table1.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Search1.css">
    <link rel="stylesheet" href="assets/css/Profile-Edit-Form.css">
    <link rel="stylesheet" href="assets/css/Profile-Edit-Form1.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1>Change password</h1>
                </div>
            </div>
            <form method="POST" action="includes/seer_resetPass.inc.php">
                <div class="row">
                    <div class="col-md-12">
                        <h4>Enter new password</h4>
                        <input type="password" placeholder="Enter password" name="password_new">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <h4>Confirm new password</h4>
                        <input type="password" placeholder="Confirm password" name="password_confirm">
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-12">
                        <a class="btn btn-default" role="button" href="login.php">Cancel </a>
    <!--                         <button type="submit" name="submit" class="btn btn btn-default" style="background-color:green;color:white;">Save</button> -->
                        <input type="submit" name="submit" class="btn btn btn-default" style="background-color:green;color:white;" value="Save">
                    </div>
                </div>
            </form>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
    <script src="assets/js/bs-animation.js"></script>
    <script src="assets/js/Profile-Edit-Form.js"></script>
</body>
</html>