<?php
    define('RESTRICTED', true);
    
    include_once 'includes/seer_head.inc.php'
?>

<body>
    <?php
        include_once 'includes/seer_navbar.inc.php';
    ?>
    <div class="form-group" id="mainbod">
        <div class="row">
            <div class="col-md-12" id="heading">
                <h1>Profile </h1>
            </div>
            <div class="col-lg-4 col-md-12" id="pfn"><label class="control-label">Last name</label>
                <?php
                    echo "<p>".$_SESSION['user_lastSession']."</p>";
                ?>
            </div>
            <div class="col-lg-4 col-md-12" id="pmi"><label class="control-label">First name</label>
                <?php
                    echo "<p>".$_SESSION['user_firstSession']."</p>";
                ?>
            </div>
            <div class="col-lg-4 col-md-12" id="pln"><label class="control-label">Middle initial</label>
                <?php
                    echo "<p>".$_SESSION['user_MISession']."</p>";
                ?>
            </div>
            <div class="col-md-12">
                <hr>
            </div>
            <div class="col-lg-4 col-md-12" id="email"><label class="control-label">E-mail </label>
                <?php
                    echo "<p>".$_SESSION['user_emailSession']."</p>";
                ?>
            </div>
            <div class="col-lg-4 col-md-12" id="accnttype"><label class="control-label">Account Type</label>
                <?php
                           if ($_SESSION['user_is_adminSession'] == 1) {
                               echo "<p>Administrator</p>";
                           } elseif ($_SESSION['user_is_adminSession'] == 0) {
                               echo "<p>Faculty</p>";
                           } else {
                                header("Location: seer_home.php?account_type=UNRECOGNIZED");
                                exit();
                           }
                        ?>
            </div>
            <div class="col-md-12">
                <hr>
            </div>
            <div class="col-lg-5 col-md-12" id="chngpw"><a href="#" data-toggle="modal" data-target="#change-pass">Change password</a></div>
        </div>
        <div class="modal fade" role="dialog" tabindex="-1" id="change-passlog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                        <h4 class="modal-title">Modal Title</h4>
                    </div>
                    <div class="modal-body">
                        <p>The content of your modal.</p>
                    </div>
                    <div class="modal-footer"><button class="btn btn-default" type="button" data-dismiss="modal">Close</button><button class="btn btn-primary" type="button">Save</button></div>
                </div>
            </div>
        </div>
        <div class="modal fade" role="dialog" tabindex="-1" id="change-pass">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form method="POST" action="includes/seer_changePassword.inc.php">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                            <h4 class="modal-title">Change password</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-lg-6 col-md-12"><p>Current password</p></div>
                                <div class="col-lg-6 col-md-12"><input type="password" name="pass_old"></div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6 col-md-12"><p>New password</p></div>
                                <div class="col-lg-6 col-md-12"><input type="password" name="pass_new"></div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6 col-md-12"><p>Confirm new password</p></div>
                                <div class="col-lg-6 col-md-12"><input type="password" name="pass_confirm"></div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-default" type="button" data-dismiss="modal">Close</button>
                            <button class="btn btn-primary" type="submit" style="background-color:green;" name="submit">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
    <script src="assets/js/bs-animation.js"></script>
</body>

</html>