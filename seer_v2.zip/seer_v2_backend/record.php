<?php
    define('RESTRICTED',true);

    include_once 'includes/seer_head.inc.php';
?>
<body>
<div class="modal fade" role="dialog" tabindex="-1" id="addstud">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title">Add student record</h4>
            </div>
            <div class="modal-body">
                <form action="includes/seer_addStudent.inc.php" method="POST">
                    <div class="row" id="rowstudn">
                        <div class="col-lg-6 col-md-12">
                            <p>Student Number</p>
                        </div>
                        <div class="col-lg-6 col-md-12"><input type="number" max="2099999999" min="2000001001" style="width:177px;" name="stud_no" placeholder="ex: 2018567483" required></div>
                    </div>
                    <div class="row" id="rowln">
                        <div class="col-lg-6 col-md-12">
                            <p>Last name</p>
                        </div>
                        <div class="col-lg-6 col-md-12"><input type="text" style="width:177px;" name="stud_last" required maxlength="20"></div>
                    </div>
                    <div class="row" id="rowfn">
                        <div class="col-lg-6 col-md-12">
                            <p>First name</p>
                        </div>
                        <div class="col-lg-6 col-md-12"><input type="text" style="width:177px;" name="stud_first" required maxlength="20"></div>
                    </div>
                    <div class="row" id="rowmi">
                        <div class="col-lg-6 col-md-12">
                            <p>Middle initial</p>
                        </div>
                        <div class="col-lg-6 col-md-12">
                            <input type="text" style="width:177px;" name="stud_MI" required maxlength="1">
                        </div>
                        <div class="col-md-12 form-inline">
                            <div class="form-group">
                                <label >Year level</label>
                                <select class="form-control" name="stud_year" required>
                                    <option value="0"selected disabled>select one</option>
                                    <option value="1">First Year</option>
                                    <option value="2">Second Year</option>
                                    <option value="3">Third Year</option>
                                    <option value="4">Fourth Year</option>
                                    <option value="5">Fifth Year</option>
                                    <option value="6">Sixth Year</option>
                                    <option value="7">Seventh Year</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <hr>
                        <button class="btn btn-default" type="button" data-dismiss="modal">Close</button>
                        <button class="btn btn-primary" type="submit" style="background-color:green;color:white;" name="submit">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php
    include_once 'includes/seer_navbar.inc.php';
?>
<div class="form-group" id="mainbod">
    <div class="row">
        <div class="col-md-12">
            <h1>Records </h1>
        </div>
        <div class="col-lg-12 col-md-12">
            <h4>Search by</h4>
        </div>
        <form method="GET" action="record.php?" class="form-inline">
            <div class="col-lg-3 col-md-12">
                <div class="form-group">
                    <label >Status</label>
                    <select  class="form-control" name="status">
                        <?php
                            if (isset($_GET['status'])) {
                                if ($_GET['status'] == "1") {
                                    echo '
                                    <option>-- select one --</option>
                                    <option value="any">Any</option>
                                    <option value="1" selected="selected">Regular</option>
                                    <option value="2">Irregular</option>
                                    <option value="3main">Conditional All</option>
                                    <option value="3a">--Conditional C1</option>
                                    <option value="3b">--Conditional C2</option>
                                    <option value="4main">Debarred All</option>
                                    <option value="4a">--Debarred D1</option>
                                    <option value="4b">--Debarred D2</option>
                                    <option value="4c">--Debarred D3</option>
                                    <option value="4d">--Debarred D4</option>';
                                } elseif ($_GET['status'] == "2") {
                                    echo '
                                    <option>-- select one --</option>
                                    <option value="any">Any</option>
                                    <option value="1">Regular</option>
                                    <option value="2" selected="selected">Irregular</option>
                                    <option value="3main">Conditional All</option>
                                    <option value="3a">--Conditional C1</option>
                                    <option value="3b">--Conditional C2</option>
                                    <option value="4main">Debarred All</option>
                                    <option value="4a">--Debarred D1</option>
                                    <option value="4b">--Debarred D2</option>
                                    <option value="4c">--Debarred D3</option>
                                    <option value="4d">--Debarred D4</option>';
                                } elseif ($_GET['status'] == "3main") {
                                    echo '
                                    <option>-- select one --</option>
                                    <option value="any">Any</option>
                                    <option value="1">Regular</option>
                                    <option value="2">Irregular</option>
                                    <option value="3main" selected="selected" style="font-weight: bold;">Conditional All</option>
                                    <option value="3a">--Conditional C1</option>
                                    <option value="3b">--Conditional C2</option>
                                    <option value="4main">Debarred All</option>
                                    <option value="4a">--Debarred D1</option>
                                    <option value="4b">--Debarred D2</option>
                                    <option value="4c">--Debarred D3</option>
                                    <option value="4d">--Debarred D4</option>';
                                } elseif ($_GET['status'] == "3a") {
                                    echo '
                                    <option>-- select one --</option>
                                    <option value="any">Any</option>
                                    <option value="1">Regular</option>
                                    <option value="2">Irregular</option>
                                    <option value="3main">Conditional All</option>
                                    <option value="3a" selected="selected">--Conditional C1</option>
                                    <option value="3b">--Conditional C2</option>
                                    <option value="4main">Debarred All</option>
                                    <option value="4a">--Debarred D1</option>
                                    <option value="4b">--Debarred D2</option>
                                    <option value="4c">--Debarred D3</option>
                                    <option value="4d">--Debarred D4</option>';
                                } elseif ($_GET['status'] == "3b") {
                                    echo '
                                    <option>-- select one --</option>
                                    <option value="any">Any</option>
                                    <option value="1">Regular</option>
                                    <option value="2">Irregular</option>
                                    <option value="3main">Conditional All</option>
                                    <option value="3a">--Conditional C1</option>
                                    <option value="3b" selected="selected">--Conditional C2</option>
                                    <option value="4main">Debarred All</option>
                                    <option value="4a">--Debarred D1</option>
                                    <option value="4b">--Debarred D2</option>
                                    <option value="4c">--Debarred D3</option>
                                    <option value="4d">--Debarred D4</option>';
                                } elseif ($_GET['status'] == "4main") {
                                    echo '
                                    <option>-- select one --</option>
                                    <option value="any">Any</option>
                                    <option value="1">Regular</option>
                                    <option value="2">Irregular</option>
                                    <option value="3main">Conditional All</option>
                                    <option value="3a">--Conditional C1</option>
                                    <option value="3b">--Conditional C2</option>
                                    <option value="4main" selected="selected" style="font-weight: bold;">Debarred All</option>
                                    <option value="4a">--Debarred D1</option>
                                    <option value="4b">--Debarred D2</option>
                                    <option value="4c">--Debarred D3</option>
                                    <option value="4d">--Debarred D4</option>';
                                } elseif ($_GET['status'] == "4a") {
                                    echo '
                                    <option>-- select one --</option>
                                    <option value="any">Any</option>
                                    <option value="1">Regular</option>
                                    <option value="2">Irregular</option>
                                    <option value="3main">Conditional All</option>
                                    <option value="3a">--Conditional C1</option>
                                    <option value="3b">--Conditional C2</option>
                                    <option value="4main">Debarred All</option>
                                    <option value="4a" selected="selected">--Debarred D1</option>
                                    <option value="4b">--Debarred D2</option>
                                    <option value="4c">--Debarred D3</option>
                                    <option value="4d">--Debarred D4</option>';
                                } elseif ($_GET['status'] == "4b") {
                                    echo '
                                    <option>-- select one --</option>
                                    <option value="any">Any</option>
                                    <option value="1">Regular</option>
                                    <option value="2">Irregular</option>
                                    <option value="3main">Conditional All</option>
                                    <option value="3a">--Conditional C1</option>
                                    <option value="3b">--Conditional C2</option>
                                    <option value="4main">Debarred All</option>
                                    <option value="4a">--Debarred D1</option>
                                    <option value="4b" selected="selected">--Debarred D2</option>
                                    <option value="4c">--Debarred D3</option>
                                    <option value="4d">--Debarred D4</option>';
                                } elseif ($_GET['status'] == "4c") {
                                    echo '
                                    <option>-- select one --</option>
                                    <option value="any">Any</option>
                                    <option value="1">Regular</option>
                                    <option value="2">Irregular</option>
                                    <option value="3main">Conditional All</option>
                                    <option value="3a">--Conditional C1</option>
                                    <option value="3b">--Conditional C2</option>
                                    <option value="4main">Debarred All</option>
                                    <option value="4a">--Debarred D1</option>
                                    <option value="4b">--Debarred D2</option>
                                    <option value="4c" selected="selected">--Debarred D3</option>
                                    <option value="4d">--Debarred D4</option>';
                                } elseif ($_GET['status'] == "4d") {
                                    echo '
                                    <option>-- select one --</option>
                                    <option value="any">Any</option>
                                    <option value="1">Regular</option>
                                    <option value="2">Irregular</option>
                                    <option value="3main">Conditional All</option>
                                    <option value="3a">--Conditional C1</option>
                                    <option value="3b">--Conditional C2</option>
                                    <option value="4main">Debarred All</option>
                                    <option value="4a">--Debarred D1</option>
                                    <option value="4b">--Debarred D2</option>
                                    <option value="4c">--Debarred D3</option>
                                    <option value="4d" selected="selected">--Debarred D4</option>';
                                } elseif ($_GET['status'] == "any") {
                                    echo '
                                    <option>-- select one --</option>
                                    <option value="any" selected="selected">Any</option>
                                    <option value="1">Regular</option>
                                    <option value="2">Irregular</option>
                                    <option value="3main">Conditional All</option>
                                    <option value="3a">--Conditional C1</option>
                                    <option value="3b">--Conditional C2</option>
                                    <option value="4main">Debarred All</option>
                                    <option value="4a">--Debarred D1</option>
                                    <option value="4b">--Debarred D2</option>
                                    <option value="4c">--Debarred D3</option>
                                    <option value="4d">--Debarred D4</option>';
                                } else {
                                    echo '
                                    <option disabled="disabled" selected="selected">-- select one --</option>
                                    <option value="any">Any</option>
                                    <option value="1">Regular</option>
                                    <option value="2">Irregular</option>
                                    <option value="3main">Conditional All</option>
                                    <option value="3a">--Conditional C1</option>
                                    <option value="3b">--Conditional C2</option>
                                    <option value="4main">Debarred All</option>
                                    <option value="4a">--Debarred D1</option>
                                    <option value="4b">--Debarred D2</option>
                                    <option value="4c">--Debarred D3</option>
                                    <option value="4d">--Debarred D4</option>';
                                } 
                            } else {
                                echo '
                                <option disabled="disabled" selected="selected">-- select one --</option>
                                <option value="any">Any</option>
                                <option value="1">Regular</option>
                                <option value="2">Irregular</option>
                                <option value="3main">Conditional All</option>
                                <option value="3a">--Conditional C1</option>
                                <option value="3b">--Conditional C2</option>
                                <option value="4main">Debarred All</option>
                                <option value="4a">--Debarred D1</option>
                                <option value="4b">--Debarred D2</option>
                                <option value="4c">--Debarred D3</option>
                                <option value="4d">--Debarred D4</option>';
                            }
                        ?>
                    </select>
                </div>
            </div>
            <div class="col-lg-2 col-md-12" style="margin-left: -130px;">
                <div class="form-group">
                    <label >Year</label>
                     <select  class="form-control" name="year">
                     <?php
                        if (isset($_GET['year'])) {
                            if ($_GET['year'] == 'any') {
                                echo '
                                <option>-- select one --</option>
                                <option value="any" selected="selected">Any</option>
                                <option value="1">1st Year</option>
                                <option value="2">2nd Year</option>
                                <option value="3">3rd Year</option>
                                <option value="4">4th Year</option>
                                <option value="5">5th Year</option>
                                <option value="6">6th Year</option>
                                <option value="7">7th Year</option>';
                            } elseif ($_GET['year'] == '1') {
                                echo '
                                <option>-- select one --</option>
                                <option value="any">Any</option>
                                <option value="1" selected="selected">1st Year</option>
                                <option value="2">2nd Year</option>
                                <option value="3">3rd Year</option>
                                <option value="4">4th Year</option>
                                <option value="5">5th Year</option>
                                <option value="6">6th Year</option>
                                <option value="7">7th Year</option>';
                            } elseif ($_GET['year'] == '2') {
                                echo '
                                <option>-- select one --</option>
                                <option value="any">Any</option>
                                <option value="1">1st Year</option>
                                <option value="2" selected="selected">2nd Year</option>
                                <option value="3">3rd Year</option>
                                <option value="4">4th Year</option>
                                <option value="5">5th Year</option>
                                <option value="6">6th Year</option>
                                <option value="7">7th Year</option>';
                            } elseif ($_GET['year'] == '3') {
                                echo '
                                <option>-- select one --</option>
                                <option value="any">Any</option>
                                <option value="1">1st Year</option>
                                <option value="2" >2nd Year</option>
                                <option value="3" selected="selected">3rd Year</option>
                                <option value="4">4th Year</option>
                                <option value="5">5th Year</option>
                                <option value="6">6th Year</option>
                                <option value="7">7th Year</option>';
                            } elseif ($_GET['year'] == '4') {
                                echo '
                                <option>-- select one --</option>
                                <option value="any">Any</option>
                                <option value="1">1st Year</option>
                                <option value="2">2nd Year</option>
                                <option value="3">3rd Year</option>
                                <option value="4" selected="selected">4th Year</option>
                                <option value="5">5th Year</option>
                                <option value="6">6th Year</option>
                                <option value="7">7th Year</option>';
                            } elseif ($_GET['year'] == '5') {
                                echo '
                                <option>-- select one --</option>
                                <option value="any">Any</option>
                                <option value="1">1st Year</option>
                                <option value="2">2nd Year</option>
                                <option value="3">3rd Year</option>
                                <option value="4">4th Year</option>
                                <option value="5" selected="selected">5th Year</option>
                                <option value="6">6th Year</option>
                                <option value="7">7th Year</option>';
                            } elseif ($_GET['year'] == '6') {
                                echo '
                                <option>-- select one --</option>
                                <option value="any">Any</option>
                                <option value="1">1st Year</option>
                                <option value="2">2nd Year</option>
                                <option value="3">3rd Year</option>
                                <option value="4">4th Year</option>
                                <option value="5">5th Year</option>
                                <option value="6" selected="selected">6th Year</option>
                                <option value="7">7th Year</option>';
                            } elseif ($_GET['year'] == '7') {
                                echo '
                                <option>-- select one --</option>
                                <option value="any">Any</option>
                                <option value="1">1st Year</option>
                                <option value="2">2nd Year</option>
                                <option value="3">3rd Year</option>
                                <option value="4">4th Year</option>
                                <option value="5">5th Year</option>
                                <option value="6">6th Year</option>
                                <option value="7" selected="selected">7th Year</option>';
                            } else {
                                echo '
                                <option disabled="disabled" selected="selected">-- select one --</option>
                                <option value="any">Any</option>
                                <option value="1">1st Year</option>
                                <option value="2">2nd Year</option>
                                <option value="3">3rd Year</option>
                                <option value="4">4th Year</option>
                                <option value="5">5th Year</option>
                                <option value="6">6th Year</option>
                                <option value="7">7th Year</option>';
                            }
                        } else {
                            echo '
                                <option disabled="disabled" selected="selected">-- select one --</option>
                                <option value="any">Any</option>
                                <option value="1">1st Year</option>
                                <option value="2">2nd Year</option>
                                <option value="3">3rd Year</option>
                                <option value="4">4th Year</option>
                                <option value="5">5th Year</option>
                                <option value="6">6th Year</option>
                                <option value="7">7th Year</option>';
                        }
                     ?>
                      </select>
                </div>
            </div>
            <div class="radio col-lg-3 col-md-12">
                <?php 
                    if (isset($_GET['order'])) {
                        if ($_GET['order'] == "ascending") {
                            echo '
                            <label style="margin-left: -30px;"><input type="radio" name="order" value="ascending" checked>Ascending</label><br>
                            <label style="margin-left: -30px;"><input type="radio" name="order" value="descending">Descending</label>';
                        } elseif ($_GET['order'] == "descending") {
                            echo '
                            <label style="margin-left: -30px;"><input type="radio" name="order" value="ascending">Ascending</label><br>
                            <label style="margin-left: -30px;"><input type="radio" name="order" value="descending" checked>Descending</label>';
                        }
                    } else {
                        echo '
                        <label style="margin-left: -30px;"><input type="radio" name="order" value="ascending">Ascending</label><br>
                        <label style="margin-left: -30px;"><input type="radio" name="order" value="descending">Descending</label>';
                    }
                ?>
            </div>
            <div class="col-lg-1 col-md-12">
                <button class="btn btn-default" type="submit" id="rgo" style="background-color:green;color:white; margin-left: -260px;">Go </button>
            </div>
        </form>
        <div class="col-md-12">
            <hr>
        </div>
    </div>
            <?php
                include_once 'includes/seer_displayRecords.inc.php';
                
            ?>
    <footer>
            <hr>
            <form action="" name="view-record" method="POST">
                <button class="btn btn-default" type="submit">View record</button>
            </form>
            <button class="btn btn-default radd" type="button" style="background-color:green;color:white;margin:10px;" data-toggle="modal" data-target="#addstud">Add student</button>
    </footer>
</div>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
<script src="assets/js/bs-animation.js"></script>
</body>
</html>