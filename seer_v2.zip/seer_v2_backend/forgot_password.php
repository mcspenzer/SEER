<?php
    include_once 'includes/seer_head.inc.php';
?>

<body>
    <div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1>Forgot password?</h1>
                </div>
            </div>
            <form method="POST" action="includes/seer_forgotPass.inc.php">
                <div class="row">
                    <div class="col-md-12">
                        <h4>Enter e-mail</h4>
                        <input type="text" placeholder="Enter e-mail" style="width:234px;" name="emailToVerify"></div>
                    <div class="col-md-12">
                        <hr>
                    </div>
                    <div class="col-md-12" id="fpbut">
                        <a href="login.php" style="color: black;" class="btn btn-default">Back</a>
                        <button type="submit" name="submit" class="btn btn-default" style="width:230px;background-color:green;color:white;"" id="fpsend">Send me a verification code</button>
                        <hr>
                    </div>
                    <div class="col-md-12">
                        <p>A link for resetting your password will be sent to your email.</p>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
    <script src="assets/js/bs-animation.js"></script>
    <script src="assets/js/Profile-Edit-Form.js"></script>
</body>

</html>