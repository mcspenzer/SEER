<?php
session_start();

//CHECK IF PAGE IS RESTRICTED AND NEEDS AUTHENTICATION
if (defined('RESTRICTED')) {

    //CHECK IF THERE IS NOT A USER ID IN SESSION
    if (!isset($_SESSION['user_idSession'])) {

        //NO USER ID IN SESSION
        header('Location: login.php?redirect=nosession');
        exit();
    }
} else {

    //CHECK IF GET[LOGOUT] INDEX IS DEFINED
    if (isset($_GET['logout'])) {

        //REMOVE SESSION CONTENTS
        $_SESSION = array();
    }
    
    //CHECK IF PAGE SHOULD REDIRECT TO HOME AND SESSION IS SET
    if (defined('SEND_TO_HOME') && isset($_SESSION['user_idSession'])) {

        //REDIRECT TO HOME
        header('Location: home.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Practice v8.0</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:400,700">
    <link rel="stylesheet" href="assets/css/Data-Table.css">
    <link rel="stylesheet" href="assets/css/Data-Table1.css">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="assets/css/Footer-Clean.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/Login-Center.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Button1.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Search1-1.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Search1.css">
    <link rel="stylesheet" href="assets/css/Registration-Form-with-Photo.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <script src ="../assets/js/jquery-3.3.1.min.js"></script>
</head>