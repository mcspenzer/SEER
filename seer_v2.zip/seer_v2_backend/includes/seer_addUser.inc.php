<?php
/**
 * 
 * FILE [seer_addUser.inc.php]
 * 
 * MODULE TO SUPPORT NEW USERS TO BE SUPPORTED IN THE SYSTEM AND ADDED TO THE DATABASE
 * 
 */

//CHECK IF POST METHOD IS USED
if (isset($_POST['submit'])) {

	//DEPENDENCY FOR CONNECTING TO THE DATABASE
	include_once 'seer_database.inc.php';

	/**
	 * 
	 * INITIALIZATION OF VARIABLES.
	 * VALUES ARE OBTAINED THROUGH
	 * POST METHOD
	 * 
	 */

	//NEW USER INFORMATION
	$last 			 = mysqli_real_escape_string($connect, $_POST['add_last']);					//NEW USER LAST NAME
	$first 			 = mysqli_real_escape_string($connect, $_POST['add_first']);				//NEW USER FIRST NAME
	$MI 			 = mysqli_real_escape_string($connect, $_POST['add_MI']);					//NEW USER MIDDLE INITIAL

	//NEW USER CREDENTIALS
	$username 		 = mysqli_real_escape_string($connect, $_POST['add_username']);				//NEW USER USERNAME
	$password 		 = mysqli_real_escape_string($connect, $_POST['add_password']);				//NEW USER PASSWORD
	$passwordConfirm = mysqli_real_escape_string($connect, $_POST['add_passwordConfirm']);		//CONFIRM PASSWORD
	$email 			 = mysqli_real_escape_string($connect, trim($_POST['add_email']));			//NEW USER EMAIL ADDRESS
	$emailConfirm 	 = mysqli_real_escape_string($connect, trim($_POST['add_emailConfirm']));	//CONFIRM EMAIL ADDRESS
	$accountType 	 = mysqli_real_escape_string($connect, $_POST['add_accountType']);			//NEW USER ACCOUNT TYPE

	/**
	 * 
	 * ERROR HANDLERS
	 * 
	 */

	//CHECK IF NAME FIELDS ARE EMPTY
	if (empty($last) || empty($first) || empty($MI)) {

		//NAME FIELDS ARE EMPTY
		header("Location: ../accounts.php?register=NULL");
		exit();
	} else {

		//CHECK SYNTAX FOR NAME FIELDS ARE CORRECT
		if (!preg_match("/^[a-zA-Z_ -]*$/", $last) || !preg_match("/^[a-zA-Z_ -]*$/", $first) || !preg_match("/^[a-zA-Z]*$/", $MI)) {

			//INVALID NAME FIELDS
			header("Location: ../accounts.php?register=INVALID_NAME");
			exit();
		} else {

			//CHECK IF USERNAME DOES NOT HAVE SPECIAL CHARACTERS
			if(!preg_match("/^[a-zA-Z0-9]*$/", $username)) {

				//USERNAME CONTAINS INVALID CHARACTERS
				header("Location: ../accounts.php?register=INVALID_UNAME");
				exit();
			} else {

				//CHECK IF EMAIL IS VALID
				if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

					//EMAIL IS INVALID
					header("Location: ../accounts.php?register=INVALID_EMAIL");
					exit();
				} else {

					//CHECK IF EMAIL IS TRUE
					if ($email !=  $emailConfirm) {

						//EMAIL DOES NOT MATCH
						header("Location: ../accounts.php?register=EMAIL_NOT_MATCH");
						exit();
					} else {

						//SQL QUERY FOR VERIFYING IF THE EMAIL IS ALREADY REGISTERED
						$sql_query = "SELECT * FROM users WHERE user_email = '$email'";

						//RESULT OF THE SQL QUERY
						$sql_result = mysqli_query($connect, $sql_query);

						//NUMBER OF ROWS AFFECTED 
						$sql_check = mysqli_num_rows($sql_result);

						//CHECK IF EMAIL IS ALREADY REGISTERED
						if ($sql_check > 0) {

							//EMAIL IS ALREADY REGISTERED
							header("Location: ../accounts.php?register=EMAIL_ALREADY_IN_USE");
							exit();
						} else {

							//CHECK IF PASSWORD IS TRUE
							if ($password != $passwordConfirm) {

								//PASSWORD DOES NOT MATCH
								header("Location: ../accounts.php?register=PASSWORD_NOT_MATCH");
								exit();
							} else {

								//HASH THE PASSWORD USING DEFAULT PASSWORD HASHING METHODS
								$hashedPassword = password_hash($password, PASSWORD_DEFAULT);
								
								//SET THE ACCOUNT TYPE; 0 IF FOR FACULTY, 1 FOR ADMINISTRATOR
								$is_admin = 0;

								//CHECK THE ACCOUNT TYPE
								if ($accountType == "Administrator") {

									//ADMINISTRATOR ACCOUNT
									$is_admin = 1;
								} elseif ($accountType == "Faculty") {

									//FACULTY ACCOUNT
									$is_admin = 0;
								}

								//PRIME THE DEFAULT TIMEZONE FOR DATE CREATED FIELD
								date_default_timezone_set('Asia/Manila');

								//THE DATE CREATED
								$date_created = date("Y-m-d H:i:s");

								//SQL QUERY TO INSERT THE NEW USER IF ALL CHECKS ARE SATISFIED
								$sql_query = "INSERT INTO users 
									(user_username, user_first, user_last, user_MI, user_email, user_password, user_is_admin, date_created) VALUES 
									('$username',   '$first',   '$last',   '$MI',   '$email',   '$hashedPassword', '$is_admin', '$date_created')";

								//SUBMITS THE QUERY
								mysqli_query($connect, $sql_query);

								//REGISTRATION SUCCESSFUL
								header("Location: ../accounts.php?register=SUCCESS");
								exit();
							}
						}
					}
				}
			}
		}
	}
} else {

	//METHOD POST IS NOT USED
	header("Location: ../accounts.php?addUser=INVALID_METHOD");
	exit();
}