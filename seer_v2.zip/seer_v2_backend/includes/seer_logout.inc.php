<?php
/**
 * 
 * FILE [seer_logout.inc.php]
 * 
 * MODULE FOR THE LOGOUT FEATURE
 * 
 */

	//CHECK IF POST IS USED TO LOGOUT
	if (isset($_POST['logout'])) {
		session_start();									//START SESSION
		session_unset();									//UNSET SESSION
		session_destroy();									//DESTROY SESSION
		header("Location: ../login.php?logout=true");		//REDIRECT TO LOGIN PAGE
		exit();												//EXIT SCRIPT
	}
