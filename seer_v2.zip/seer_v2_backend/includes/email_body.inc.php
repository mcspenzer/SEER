<?php
/**
 * 
 * FILE [email_body.inc.php]
 * 
 * MODULE FOR SENDING THE EMAIL BODY
 * 
 */

//EMAIL - HTML FORM
$email_html = '
    <!DOCTYPE html>
    <html>

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>email_body</title>
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:400,700">

    </head>

    <body>
        <div class="jumbotron">
            <h1>Hello, '.$sql_row['user_first'].'!</h1>
            <p>Our system has received a password reset request for the account associated with this email. Please follow the button below to reset your password. If you did not request this action, please disregard and delete this email immediately.</p>
            <p><a class="btn btn-default" role="button" href="../reset_password.php?verify='.$timestampHash.'&email='.$email.'" style="margin:auto; width:50%; padding:10px; text-align:center; margin-left:42%; background-color:green; color:white;">Reset your password here</a></p>
        </div>
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    </body>

    </html>
';

//EMAIL - PLAIN TEXT FORM
$email_plain = 'Hello, '.$sql_row['user_first'].'! Our system has received a password reset request for the account associated with this email. Please follow the button below to reset your password. If you did not request this action, please disregard and delete this email immediately. Link: localhost/reset_password.php?verify='.$timestampHash.'$email='.$email;
?>