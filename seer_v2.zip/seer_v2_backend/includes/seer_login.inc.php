<?php
/**
 * 
 * FILE [seer_login.inc.php]
 * 
 * MODULE FOR THE LOGIN FUNCTION
 * 
 */
session_start();

//CHECK IF POST METHOD IS USED
if (isset($_POST['submit'])) {

	//INCLUDE DEPENDENCIES FOR DATABASE OPERATIONS
	include 'seer_database.inc.php';

	$login_email 	= mysqli_real_escape_string($connect, $_POST['email']);				//THE LOGIN EMAIL OF THE USER
	$login_password = mysqli_real_escape_string($connect, $_POST['password']);			//THE LOGIN PASSWORD OF THE USER

	//CHECK IF NO VALUE IS ASSIGNED TO EMAIL AND PASSWORD
	if (empty($login_email) || empty($login_password)) {

		//NO EMAIL OR PASSWORD SUBMITTED
		header("Location: ../login.php?login=NULL");
		exit();
	} else {

		$sql_query = "SELECT * FROM users WHERE user_email = '$login_email'";			//SQL STATEMENT FOR SELECTING THE USER EMAIL
		$sql_result = mysqli_query($connect, $sql_query);								//SQL STATEMENT RESULT
		$sql_check = mysqli_num_rows($sql_result);										//SQL STATEMENT ALL ROWS AFFECTED

		//CHECK IF MORE THAN ONE RESULT
		if ($sql_check > 1) {

			//LOGIN IS INVALID
			header("Location: ../login.php?login=INVALID");
			exit();
		} else {

			//CHECK IF THERE IS A ROW SELECTED
			if ($row = mysqli_fetch_assoc($sql_result)) {

				//DEHASH PASSWORD
				$hashedPasswordCheck = password_verify($login_password, $row['user_password']);

				//CHECK IF PASSWORDS DO NOT MATCH
				if ($hashedPasswordCheck == false) {

					//PASSWORDS DO NOT MATCH
					header("Location: ../login.php?login=INVALID_PASSWORD");
					exit();

				//CHECK IF PASSWORDS MATCH
				} elseif ($hashedPasswordCheck == true) {
					//CORRECT PASSWORD; LOGIN USER
					
					/**
					 * 
					 * ASSIGN ROW VALUES TO CURRENT SESSION
					 * 
					 */
					
					$_SESSION['user_is_adminSession'] = $row['user_is_admin'];			//INSERT ADMINISTRATOR PRIVILEGES TO SESSION
					$_SESSION['user_usernameSession'] = $row['user_username'];			//INSERT USERNAME TO SESSION
					$_SESSION['user_firstSession'] = $row['user_first'];				//INSERT USER FIRST NAME TO SESSION
					$_SESSION['user_emailSession'] = $row['user_email'];				//INSERT USER EMAIL TO SESSION
					$_SESSION['user_lastSession'] = $row['user_last'];					//INSERT USER LAST NAME TO SESSION
					$_SESSION['user_idSession'] = $row['user_id'];						//INSERT USER ID TO SESSION
					$_SESSION['user_MISession'] = $row['user_MI'];						//INSERT USER MIDDLE INITIAL TO SESSION
					$_SESSION['login'] = true;											//INSERT LOGIN INDEX TO SESSION

					header("Location: ../home.php");
					exit();
				}
			}
		}
	}
} else {
	header("Location: ../login.php?login=INVALID_METHOD");
	exit();
}