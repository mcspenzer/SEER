<?php
/**
 * 
 * FILE [seer_database.inc.php]
 * 
 * MODULE TO SUPPORT DATABASE CONNECTIVITY AND QUERY FUNCTIONS 
 * 
 */

//THE DATABASE SERVER NAME TO CONNECT TO
$dbServerName = "localhost";

//THE USERNAME OF THE USER TRYING TO ACCESS THE DATABASE
$dbUserName = "root";

//THE PASSWORD OF THE USER TRYING TO ACCESS THE DATABASE
$dbPassword = "";

//THE DATABASE NAME TO APPLY QUERIES AND OPERATIONS
$dbName = "seer_db";

//USED TO CONNECT TO THE DATABASE
$connect = mysqli_connect($dbServerName, $dbUserName, $dbPassword, $dbName);