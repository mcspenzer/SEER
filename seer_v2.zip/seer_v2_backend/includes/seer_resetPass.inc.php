<?php
/**
 * 
 * FILE [seer_resetPass.inc.php]
 * 
 * MODULE FOR THE RESET PASSWORD FEATURE
 * 
 */
session_start();

//INCLUDE DATABASE ASSET TO SUPPORT DATABASE FUNCTIONS
include_once 'seer_database.inc.php';

//CHECK IF POST M IS USED
if (isset($_POST['submit'])) {

	/**
	 * 
	 * INITIALIZE VARIABLES VIA POST METHOD ARGUMENTS
	 * 
	 */
	$passConfirm = mysqli_real_escape_string($connect, $_POST['password_confirm']);			//PASSWORD CONFIRMATION
	$passNew = mysqli_real_escape_string($connect, $_POST['password_new']);					//PASSWORD NEW
	$email = $_SESSION['email'];															//RETRIEVE EMAIL FROM SESSION

	//CHECK IF VARIABLES ARE EMPTY
	if (empty($passNew) || empty($passConfirm)) {

		//VARIABLES ARE EMPTY
		header("Location ../login.php?reset=NULL");
		exit();
	} else {

		//CHECK IF NEW PASSWORD IS EQUAL TO THE NEW PASSWORD
		if ($passNew == $passConfirm) {

			//SQL STATEMENT TO SELECT THE USER REQUESTING THE RESET PASSWORD MODULE
			$sql_query = "SELECT * from users WHERE user_email ='$email'";

			//SQL RESULT OF THE STATEMENT
			$sql_result = mysqli_query($connect, $sql_query);

			//NUMBER OF AFFECTED ROWS
			$sql_check = mysqli_num_rows($sql_result);

			//CHECK IF EXACLY ONE RECORD IS SELECTED
			if ($sql_check == 1) {

				//FETCH THE ASSOCIATED ROWS FROM THE RESULT
				$row_result = mysqli_fetch_assoc($sql_result);

				//GET THE USER ID OF THE USER
				$uid = $row_result['user_id'];

				//HASH THE NEW PASSWORD
				$hashedNewPass = password_hash($passNew, PASSWORD_DEFAULT);

				//SQL QUERY TO REPLACE THE PASSWORD
				$sql_query_replacePW = "UPDATE users SET user_password = '$hashedNewPass', forgotPW_token = NULL WHERE user_id = '$uid'";

				//SQL RESULT OF THE QUERY
				$queryResult = mysqli_query($connect, $sql_query_replacePW) or trigger_error("Query Failed. Error: ".mysqli_error($connect));

				//PASSWORD CHANGE SUCCESS
				header("Location: ../reset_success.php?email=".$email);
				exit();
			} else {

				//RESULT IS INVALID
				header("Location: ../login.php?reset=INVALID_RESULT");
				exit();
			}
		} else {

			//PASSWORD CONFIRMATION DOES NOT MATCH
			header("Location: ../login.php?reset=PASSWORD_MISMATCH");
			exit();
		}
	}
} else {

	//METHOD IS INVALID
	header("Location: ../login.php?reset=INVALID_FUNCTION");
	exit();
}