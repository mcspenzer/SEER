<?php
/**
 * 
 * FILE [seer_addStudent.inc.php]
 * 
 * MODULE TO ADD A STUDENT IN THE DATABASE
 * 
 */

//CHECK IF METHOD POST IS USED
if (isset($_POST['submit'])) {
	include_once 'seer_database.inc.php';

	/**
	 * 
	 * STUDENT CREDENTIALS TO BE ADDED
	 * METHOD POST IS USED
	 * 
	 */
	$studNo = mysqli_real_escape_string($connect, $_POST['stud_no']);				//STUDENT NUMBER TO BE ADDED
	$studLast = mysqli_real_escape_string($connect, $_POST['stud_last']);			//STUDENT LAST NAME TO BE ADDED
	$studFirst = mysqli_real_escape_string($connect, $_POST['stud_first']);			//STUDENT FIRST NAME TO BE ADDED
	$studMI = mysqli_real_escape_string($connect, $_POST['stud_MI']);				//STUDENT MIDDLE INITAL TO BE ADDED
	$studYear = mysqli_real_escape_string($connect, $_POST['stud_year']);			//STUDENT YEAR TO BE ADDED

	//CHECK IF PASSED VALUES ARE NOT EMPTY
	if (empty($studNo) || empty($studLast) || empty($studFirst) || empty($studMI) || empty($studYear)) {

		//SOME FIELDS DO NOT HAVE VALUE
		header("Location: ../record.php?addStudent=NULL");
		exit();
	} else {

		//CHECK IF STUDENT NUMBER IS VALID
		if (!preg_match("/^[0-9]*$/", $studNo)) {

			//STUDENT NUMBER SYNTAX ENTERED IS NOT VALID
			header("Location: ../record.php?addStudent=INVALID_STUDNO");
			exit();
		} else {

			//CHECK IF STUDENT NAME SYNTAX IS VALID
			if (!preg_match("/^[a-zA-Z_ -]*$/", $studLast) || !preg_match("/^[a-zA-Z_ -]*$/", $studFirst) || !preg_match("/^[a-zA-Z_ -]*$/", $studMI)) {

				//NAME SYNTAX IS NOT VALID
				header("Location: ../record.php?addStudent=INVALID_NAME");
				exit();
			} else {

				//SQL QUERY FOR CHECKING IF STUDENT ALREADY EXIST IN THE DATABASE
				$sql_query = "SELECT * FROM students WHERE stud_number = '$studNo'";

				//RESULT OF THE SQL QUERY
				$sql_result = mysqli_query($connect, $sql_query);

				//NUMBER OF ROWS AFFECTED
				$sql_check = mysqli_num_rows($sql_result);

				//CHECK IF THERE IS ALREADY A STUDENT HAVING THE SAME STUDENT NUMBER ENTERED 
				if ($sql_check > 0) {

					//STUDENT ALREADY EXISTS
					header("Location: ../record.php?addStudent=STUDENT_ALREADY_EXISTS");
					exit();
				} else {

					//PRIME THE TIMEZONE FOR DATE CREATED FIELD
					date_default_timezone_set('Asia/Manila');

					//DATE THE STUDENT IS CREATED
					$date_created = date("Y-m-d H:i:s");

					//THE QUERY TO INSERT THE STUDENT IN THE DATABASE
					$sql_query = "INSERT INTO students (stud_number, stud_last, stud_first, stud_MI, stud_year, stud_status, date_added) VALUES ('$studNo', '$studLast', '$studFirst', '$studMI', '$studYear', 'R', '$date_created')";

					//INSERT THE NEW STUDENT IN THE DATABASE
					mysqli_query($connect, $sql_query);

					//INSERTION SUCCESSFUL
					header("Location: ../record.php?addStudent=SUCCESS");
					exit();
				}
			}
		}
	}
} else {

	//POST IS NOT USED TO PASS THE ARGUMENTS
	header("Location: ../record.php?addStudent=INVALID_METHOD");
	exit();
}