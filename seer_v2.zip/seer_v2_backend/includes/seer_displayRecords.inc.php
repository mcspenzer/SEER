<?php
/**
 * 
 * FILE [seer_displayRecords.inc.php]
 * 
 * MODULE TO SUPPORT DISPLAY OF RECORDS CONTAINED IN THE DATABASE TO THE SYSTEM
 * 
 */

//DEPENDENCY TO SUPPORT DATABASE FUNCTIONS
include_once 'seer_database.inc.php';

//CHECK IF PAGE NUMBER IS INCLUDED IN THE URL VIA GET
if (isset($_GET['page'])) {

	//PAGE NUMBER IS SET
	$page = $_GET['page'];
} else {

	//NO PAGE NUMBER IS SET; INITIALIZE TO PAGE 1
	$page = 1;
}

//CHECK IF THERE IS NO GET KEY-VALUE PAIRS IN THE URL
if (empty($_GET['status']) && empty($_GET['year']) && empty($_GET['order'])) {

	//DISPLAY THE INITIAL RECORDS PAGE MESSAGE
	echo "<h3>To Search for a record, please select a year and a status</h3>";

//CHECK IS STATUS AND YEAR IS SET TO ANY
} elseif ($_GET['status'] == 'any' && $_GET['year'] == 'any') {

	//DISPLAY THE TABLE FOR THE RECORDS
	echo "
	<table id='example' class='table table-striped table-bordered' cellspacing='0' width='50%'>
		<thead>
			<tr>
				<th>Student Number</th>
				<th>Last Name</th>
				<th>First Name</th>
				<th>Middle Initial</th>
				<th>Year</th>
				<th>Status</th>
			</tr>
		</thead>
	<tbody>";

	//INITIAL SQL QUERY STATEMENT
	$sql_query = "SELECT * FROM students";

	//RESULTS PER PAGE
	$results_per_page = 10;

	//OFFSET IF RESULTS DOES NOT FIT IN A SINGLE PAGE
	$start_from = ($page - 1) * $results_per_page;
	
	//SQL QUERY IS UPDATED TO LIMIT RESULTS AND START FROM THE OFFSET NUMBER
	$sql_query .= " LIMIT ".$results_per_page." OFFSET ".$start_from;

	//SQL RESULT 
	$sql_result = mysqli_query($connect, $sql_query);

	//NUMBER OF ROWS AFFECTED
	$sql_number_of_rows = mysqli_num_rows($sql_result);

	//TOTAL PAGES TO BE CREATED BASED ON THE NUMBER OF ROWS SELECTED
	$total_pages = ceil(mysqli_num_rows(mysqli_query($connect, "SELECT * FROM students")) / $results_per_page);

	//TOTAL NUMBER OF ROWS SELECTED
	echo "total rows: ".$sql_number_of_rows." ";

	//WHILE LOOP TO ITERATE THROUGH EVERY RECORDS SELECTED ON THE STATEMENT
	while ($row_result = mysqli_fetch_assoc($sql_result)) {

		//ECHO THE TABLE ROW CONTAINING THE SELECTED STUDENTS' RECORD
		echo "
		<tr>	
			<td><a href='view_record.php?studno=".$row_result['stud_number']."' target='_blank'>".$row_result['stud_number']."</a></td>
			<td>".$row_result['stud_last']."</td>
			<td>".$row_result['stud_first']."</td>
			<td>".$row_result['stud_MI']."</td>";

		//SWITCH STATEMENT FOR THE STUDENT YEAR
		switch ($row_result['stud_year']) {

			//IF STUDENT YEAR FIELD == 1, CONVERT TO STRING FIRST YEAR
			case '1':
				echo "<td>First Year</td>";
				break;

			//IF STUDENT YEAR FIELD == 2, CONVERT TO STRING SECOND YEAR
			case '2':
				echo "<td>Second Year</td>";
				break;

			//IF STUDENT YEAR FIELD == 3, CONVERT TO STRING THIRD YEAR
			case '3':
				echo "<td>Third Year</td>";
				break;

			//IF STUDENT YEAR FIELD == 4, CONVERT TO STRING FOURTH YEAR
			case '4':
				echo "<td>Fourth Year</td>";
				break;

			//IF STUDENT YEAR FIELD == 5, CONVERT TO STRING FIFTH YEAR
			case '5':
				echo "<td>Fifth Year</td>";
				break;

			//IF STUDENT YEAR FIELD == 6, CONVERT TO STRING SIXTH YEAR
			case '6':
				echo "<td>Sixth Year</td>";
				break;

			//IF STUDENT YEAR FIELD == 7, CONVERT TO STRING SEVENTH YEAR
			case '7':
				echo "<td>Seventh Year</td>";
				break;

			//IF THE STUDENT YEAR FIELD IS NOT SET, CONVERT STRING TO NOT SET
			default:
				echo "<td>Not Set</td>";
				break;
		}

		//SWITCH STATEMENT FOR STUDENT STATUS
		switch ($row_result['stud_status']) {

			//IF THE STUDENT STATUS FIELD IS NOT SET, CONVERT STRING TO NOT CALCULATED
			case 'NC':
				echo "<td>Not calculated</td></tr>";
				break;

			//IF THE STUDENT STATUS FIELD IS == R, CONVERT STRING TO REGULAR
			case 'R':
				echo "<td>Regular</td></tr>";
				break;

			//IF THE STUDENT STATUS FIELD IS == IR, CONVERT STRING TO IRREGULAR
			case 'IR':
				echo "<td>Irregular</td></tr>";
				break;

			//IF THE STUDENT STATUS FIELD IS == C1, CONVERT STRING TO CONDITIONAL(1)
			case 'C1':
				echo "<td>Conditional(1)</td></tr>";
				break;

			//IF THE STUDENT STATUS FIELD IS == C2, CONVERT STRING TO CONDITIONAL(2)
			case 'C2':
				echo "<td>Conditional(2)</td></tr>";
				break;

			//IF THE STUDENT STATUS FIELD IS == D1, CONVERT STRING TO DEBARRED(1)
			case 'D1':
				echo "<td>Debarred(1)</td></tr>";
				break;

			//IF THE STUDENT STATUS FIELD IS == D2, CONVERT STRING TO DEBARRED(2)
			case 'D2':
				echo "<td>Debarred(2)</td></tr>";
				break;

			//IF THE STUDENT STATUS FIELD IS == D3, CONVERT STRING TO DEBARRED(3)
			case 'D3':
				echo "<td>Debarred(3)</td></tr>";
				break;

			//IF THE STUDENT STATUS FIELD IS == D4, CONVERT STRING TO DEBARRED(4)
			case 'D4':
				echo "<td>Debarred(4)</td></tr>";
				break;
		}
	}

	//TERMINATE THE TABLE
	echo "</tbody></table>";

	//NUMBER OF ROWS AFFECTED BY THE SELECT STATEMENTS 
	$final_row_count = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM students"));

	//FINAL ROW COUNT
	echo "Final Row Count: ".$final_row_count."<br>";

	//DISPLAY THE PAGE NUMBERS
	echo '<nav><ul class="pagination">';

	//CHECK IF THERE IS A NEED FOR OTHER PAGES
	if ($results_per_page < $final_row_count) {

		//DISPLAY THE PREVIOUS BUTTON
		echo '<li><a aria-label="Previous"><span aria-hidden="true">«</span></a></li>';

		//FOR LOOP TO CREATE N PAGES DEPENDING ON THE SELECT STATEMENT RESULT
		for ($i=1; $i < $total_pages + 1 ; $i++) {

			//CHECK IF ITERATOR IS == 1
			if ($i == 1) {

				//DISPLAY PAGE ONE
				echo "<li><a href='record.php?year=any&status=any&page=".$i."'>".$i."</a></li>";
				continue;
			}

			//CHECK IF ITERATOR IS EQUAL TO CURRENT PAGE
			if ($i == $page) {

				//DISPLAY THE PAGE SELECTOR ON PAGE N AND SET IT TO ACTIVE
				echo "<li class='active'><a href='record.php?year=any&status=any&page=".$i."'>".$i."</a></li>";
				continue;
			}

			//DISPLAY THE PAGE SELECTOR ON PAGE N
			echo "<li><a href='record.php?year=any&status=any&page=".$i."'>".$i."</a></li>";
		}

		//DISPLAY THE NEXT BUTTON
		echo '<li><a aria-label="Next"><span aria-hidden="true">»</span></a></li>';
	}

	//DISPLAY THE CLOSING TAG FOR THE PAGINATION
	echo '</ul></nav>';

//CHECK IF STATUS OR YEAR OR ORDER IS SET
} elseif (isset($_GET['status']) || isset($_GET['year']) || isset($_GET['order'])) {

	//INITIAL SQL QUERY STATEMENT
	$sql_query = "SELECT * FROM students";

	//RESULTS PER PAGE
	$results_per_page = 10;

	//OFFSET FOR THE SELECT STATEMENT
	$start_from = ($page - 1) * $results_per_page;

	//CHECK IF ALL THREE GET PARAMETERS ARE SET
	if (isset($_GET['status']) && isset($_GET['year']) || isset($_GET['order'])) {

		//CHECK IF STATUS IS != TO 0 AND ANY
		if ($_GET['status'] != '0' && $_GET['status'] != 'any') {

			//CHECK IF STATUS == 1
			if ($_GET['status'] == '1') {

				//SQL QUERY APPEND TO SELECT ALL REGULAR STUDENTS
				$sql_query .= " WHERE stud_status = 'R'";

			//CHECK IF STATUS == 2
			} elseif ($_GET['status'] == '2') {

				//SQL QUERY APPEND TO SELECT ALL IRREGULAR STUDENTS
				$sql_query .= " WHERE stud_status = 'IR'";

			//CHECK IF STATUS  == 3a
			} elseif ($_GET['status'] == '3a') {

				//SQL QUERY APPEND TO SELECT ALL CONDITIONAL 1 STUDENTS
				$sql_query .= " WHERE stud_status = 'C1'";

			//CHECK IF STATUS == 3b
			} elseif ($_GET['status'] == '3b') {

				//SQL QUERY APPEND TO SELECT ALL CONDITIONAL 2 STUDENTS
				$sql_query .= " WHERE stud_status = 'C2'";

			//CHECK IF STATUS == 4a
			} elseif ($_GET['status'] == '4a') {

				//SQL QUERY APPEND TO SELECT ALL DEBARRED 1 STUDENTS
				$sql_query .= " WHERE stud_status = 'D1'";

			//CHECK IF STATUS == 4b
			} elseif ($_GET['status'] == '4b') {

				//SQL QUERY APPEND TO SELECT ALL DEBARRED 2 STUDENTS
				$sql_query .= " WHERE stud_status = 'D2'";

			//CHECK IF STATUS == 4c
			} elseif ($_GET['status'] == '4c') {

				//SQL QUERY APPEND TO SELECT ALL DEBARRED 3 STUDENTS
				$sql_query .= " WHERE stud_status = 'D3'";

			//CHECK IF STATUS == 4d
			} elseif ($_GET['status'] == '4d') {

				//SQL QUERY APPEND TO SELECT ALL DEBARRED 4 STUDENTS
				$sql_query .= " WHERE stud_status = 'D4'";

			//CHECK IF STATUS == 3main
			} elseif ($_GET['status'] == '3main') {

				//SQL QUERY APPEND TO SELECT ALL CONDITIONAL STUDENTS
				$sql_query .= " WHERE stud_status LIKE 'C_'";

			//CHECK IF STATUS == 4main
			} elseif ($_GET['status'] == '4main') {

				//SQL QUERY APPEND TO SELECT ALL DEBARRED STUDENTS
				$sql_query .= " WHERE stud_status LIKE 'D_'";
			}
		}

		//CHECK IF YEAR != TO 0 AND ANY
		if ($_GET['year'] != '0' && $_GET['year'] != 'any') {

			//CHECK IF STATUS != TO STATUS AND ANY
			if ($_GET['status'] != '0' && $_GET['status'] != 'any') {

				////SQL QUERY APPEND TO ADD AND
				$sql_query .= " AND";
			} else {

				//SQL QUERY APPEND TO ADD WHERE
				$sql_query .= " WHERE";
			}
			
			//CHECK IF YEAR == 1
			if ($_GET['year'] == '1') {

				//SQL QUERY APPEND TO SELECT ALL FIRST YEAR STUDENTS
				$sql_query .= " stud_year = '1'";

			//CHECK IF YEAR == 2
			} elseif ($_GET['year'] == '2') {

				//SQL QUERY APPEND TO SELECT ALL SECOND YEAR STUDENTS
				$sql_query .= " stud_year = '2'";

			//CHECK IF YEAR == 3
			} elseif ($_GET['year'] == '3') {

				//SQL QUERY APPEND TO SELECT ALL THIRD YEAR STUDENTS
				$sql_query .= " stud_year = '3'";

			//CHECK IF YEAR == 4
			} elseif ($_GET['year'] == '4') {

				//SQL QUERY APPEND TO SELECT ALL FOURTH YEAR STUDENTS
				$sql_query .= " stud_year = '4'";

			//CHECK IF YEAR == 5
			} elseif ($_GET['year'] == '5') {

				//SQL QUERY APPEND TO SELECT ALL FIFTH YEAR STUDENTS
				$sql_query .= " stud_year = '5'";

			//CHECK IF YEAR == 6
			} elseif ($_GET['year'] == '6') {

				//SQL QUERY APPEND TO SELECT ALL SIXTH YEAR STUDENTS
				$sql_query .= " stud_year = '6'";

			//CHECK IF YEAR == 7
			} elseif ($_GET['year'] == '7') {

				//SQL QUERY APPEND TO SELECT ALL SEVENTH YEAR STUDENTS
				$sql_query .= " stud_year = '7'";
			}
		}

		//IF ORDER IS SET
		if (isset($_GET['order'])) {

			//IF ORDER == ASCENDING
			if ($_GET['order'] == 'ascending') {

				//SQL QUERY APPEND TO ORDER BY STUDENT NUMBER ASCENDING
				$sql_query .= " ORDER BY stud_number"; 

			//IF ORDER == DESCENDING
			} elseif ($_GET['order'] == 'descending') {

				//SQL QUERY APPEND TO ORDER BY STUDENT NUMBER ASCENDING
				$sql_query .= " ORDER BY stud_number DESC"; 
			}
		} else {

			//SQL QUERY APPEND TO ORDER BY STUDENT NUMBER DESCENDING
			$sql_query .= " ORDER BY stud_number"; 
		}

	//CHECK IF ONLY YEAR IS SET
	} elseif (empty($_GET['status']) && isset($_GET['year']) && empty($_GET['order'])) {

		//CHECK IF YEAR == 1
		if ($_GET['year'] == '1') {

			//SQL QUERY APPEND TO SELECT BY FIRST YEAR STUDENTS
			$sql_query .= " WHERE stud_year = '1'";

		//CHECK IF YEAR == 2
		} elseif ($_GET['year'] == '2') {

			//SQL QUERY APPEND TO SELECT BY SECOND YEAR STUDENTS
			$sql_query .= " WHERE stud_year = '2'";

		//CHECK IF YEAR == 3
		} elseif ($_GET['year'] == '3') {

			//SQL QUERY APPEND TO SELECT BY THIRD YEAR STUDENTS
			$sql_query .= " WHERE stud_year = '3'";

		//CHECK IF YEAR == 4
		} elseif ($_GET['year'] == '4') {

			//SQL QUERY APPEND TO SELECT BY FOURTH YEAR STUDENTS
			$sql_query .= " WHERE stud_year = '4'";
		} else {

			//YEAR ERROR
			header("Location: record.php?query=GET_ERROR");
			exit();
		}
	
	//CHECK IF STATUS IS ONLY SET
	} elseif (isset($_GET['status']) && empty($_GET['year']) && empty($_GET['order'])) {

		//CHECK IF STATUS == 1
		if ($_GET['status'] == '1') {

			//SQL QUERY APPEND TO SELECT BY REGULAR STUDENTS
			$sql_query .= " WHERE stud_status = 'R'";

		//CHECK IF STATUS == 2
		} elseif ($_GET['status'] == '2') {

			//SQL QUERY APPEND TO SELECT BY IRREGULAR STUDENTS
			$sql_query .= " WHERE stud_status = 'IR'";

		//CHECK IF STATUS == 3
		} elseif ($_GET['status'] == '3a') {

			//SQL QUERY APPEND TO SELECT BY CONDITIONAL 1 STUDENTS
			$sql_query .= " WHERE stud_status = 'C1'";

		//CHECK IF STATUS == 4
		} elseif ($_GET['status'] == '3b') {

			//SQL QUERY APPEND TO SELECT BY CONDITIONAL 2 STUDENTS
			$sql_query .= " WHERE stud_status = 'C2'";

		//CHECK IF STATUS == 4a
		} elseif ($_GET['status'] == '4a') {

			//SQL QUERY APPEND TO SELECT BY DEBARRED 1 STUDENTS
			$sql_query .= " WHERE stud_status = 'D1'";

		//CHECK IF STATUS == 4b
		} elseif ($_GET['status'] == '4b') {

			//SQL QUERY APPEND TO SELECT BY DEBARRED 2 STUDENTS
			$sql_query .= " WHERE stud_status = 'D2'";

		//CHECK IF STATUS == 4c
		} elseif ($_GET['status'] == '4c') {

			//SQL QUERY APPEND TO SELECT BY DEBARRED 3 STUDENTS
			$sql_query .= " WHERE stud_status = 'D3'";

		//CHECK IF STATUS == 4d
		} elseif ($_GET['status'] == '4d') {

			//SQL QUERY APPEND TO SELECT BY DEBARRED 4 STUDENTS
			$sql_query .= " WHERE stud_status = 'D4'";

		//CHECK IF STATUS == 3main
		} elseif ($_GET['status'] == '3main') {

			//SQL QUERY APPEND TO SELECT BY CONDITIONAL STUDENTS
			$sql_query .= " WHERE stud_status LIKE 'C_'";

		//CHECK IF STATUS == 4main
		} elseif ($_GET['status'] == '4main') {

			//SQL QUERY APPEND TO SELECT BY DEBARRED STUDENTS
			$sql_query .= " WHERE stud_status LIKE 'D_'";
		}
	}

	$no_offset = $sql_query;												//SQL STATEMENT WITH NO OFFSET
	$no_offset_result = mysqli_query($connect, $no_offset);					//SQL QUERY WITH NO OFFSET
	$no_offset_rows = mysqli_num_rows($no_offset_result);					//SQL QUERY APPEND TO LIMIT RESULTS AND START AT OFFSET NUMBER
	$sql_result = mysqli_query($connect, $sql_query);						//SQL RESULT OF THE QUERY
	$sql_number_of_rows = mysqli_num_rows($sql_result);						//SQL NUMBER OF ROWS AFFECTED

	//TOTAL PAGES
	$total_pages = ceil($no_offset_rows / $results_per_page);

	//SQL RESULT OF THE SELECT STATEMENT
	$sql_result = mysqli_query($connect, $sql_query);

	//CHECK IF THERE IS A ROW SELECTED
	if (mysqli_num_rows($sql_result) == 0) {

		//DISPLAY NO RESULTS FOUND
		echo "<h1>No results found</h1>";
	} else {

		//DISPLAY TABLE
		echo "
		<table id='example' class='table table-striped table-bordered' cellspacing='0' width='50%'>
			<thead>
				<tr>						
					<th>Student Number</th>
					<th>Last Name</th>
					<th>First Name</th>
					<th>Middle Initial</th>
					<th>Year</th>
					<th>Status</th>
				</tr>
			</thead>
		<tbody>";
	}

	while ($row_result = mysqli_fetch_assoc($sql_result)) {

		//ECHO THE TABLE ROW CONTAINING THE SELECTED STUDENTS' RECORD
		echo "
		<tr>	
			<td><a href='view_record.php?studno=".$row_result['stud_number']."' target='_blank'>".$row_result['stud_number']."</a></td>
			<td>".$row_result['stud_last']."</td>
			<td>".$row_result['stud_first']."</td>
			<td>".$row_result['stud_MI']."</td>";

		//SWITCH STATEMENT FOR THE STUDENT YEAR
		switch ($row_result['stud_year']) {

			//IF STUDENT YEAR FIELD == 1, CONVERT TO STRING FIRST YEAR
			case '1':
				echo "<td>First Year</td>";
				break;

			//IF STUDENT YEAR FIELD == 2, CONVERT TO STRING SECOND YEAR
			case '2':
				echo "<td>Second Year</td>";
				break;

			//IF STUDENT YEAR FIELD == 3, CONVERT TO STRING THIRD YEAR
			case '3':
				echo "<td>Third Year</td>";
				break;

			//IF STUDENT YEAR FIELD == 4, CONVERT TO STRING FOURTH YEAR
			case '4':
				echo "<td>Fourth Year</td>";
				break;

			//IF STUDENT YEAR FIELD == 5, CONVERT TO STRING FIFTH YEAR
			case '5':
				echo "<td>Fifth Year</td>";
				break;

			//IF STUDENT YEAR FIELD == 6, CONVERT TO STRING SIXTH YEAR
			case '6':
				echo "<td>Sixth Year</td>";
				break;

			//IF STUDENT YEAR FIELD == 7, CONVERT TO STRING SEVENTH YEAR
			case '7':
				echo "<td>Seventh Year</td>";
				break;

			//IF THE STUDENT YEAR FIELD IS NOT SET, CONVERT STRING TO NOT SET
			default:
				echo "<td>Not Set</td>";
				break;
		}

		//SWITCH STATEMENT FOR STUDENT STATUS
		switch ($row_result['stud_status']) {

			//IF THE STUDENT STATUS FIELD IS NOT SET, CONVERT STRING TO NOT CALCULATED
			case 'NC':
				echo "<td>Not calculated</td></tr>";
				break;

			//IF THE STUDENT STATUS FIELD IS == R, CONVERT STRING TO REGULAR
			case 'R':
				echo "<td>Regular</td></tr>";
				break;

			//IF THE STUDENT STATUS FIELD IS == IR, CONVERT STRING TO IRREGULAR
			case 'IR':
				echo "<td>Irregular</td></tr>";
				break;

			//IF THE STUDENT STATUS FIELD IS == C1, CONVERT STRING TO CONDITIONAL(1)
			case 'C1':
				echo "<td>Conditional(1)</td></tr>";
				break;

			//IF THE STUDENT STATUS FIELD IS == C2, CONVERT STRING TO CONDITIONAL(2)
			case 'C2':
				echo "<td>Conditional(2)</td></tr>";
				break;

			//IF THE STUDENT STATUS FIELD IS == D1, CONVERT STRING TO DEBARRED(1)
			case 'D1':
				echo "<td>Debarred(1)</td></tr>";
				break;

			//IF THE STUDENT STATUS FIELD IS == D2, CONVERT STRING TO DEBARRED(2)
			case 'D2':
				echo "<td>Debarred(2)</td></tr>";
				break;

			//IF THE STUDENT STATUS FIELD IS == D3, CONVERT STRING TO DEBARRED(3)
			case 'D3':
				echo "<td>Debarred(3)</td></tr>";
				break;

			//IF THE STUDENT STATUS FIELD IS == D4, CONVERT STRING TO DEBARRED(4)
			case 'D4':
				echo "<td>Debarred(4)</td></tr>";
				break;
		}
	}

	//TERMINATE THE TABLE
	echo "</tbody></table>";

	//NUMBER OF ROWS AFFECTED BY THE SELECT STATEMENTS 
	$final_row_count = mysqli_num_rows($sql_result);

	//FINAL ROW COUNT
	echo "Final Row Count: ".$final_row_count."<br> ";

	//DISPLAY THE PAGE NUMBERS
	echo '<nav><ul class="pagination">';

	//CHECK IF THERE IS A NEED FOR OTHER PAGES
	if ($results_per_page < $no_offset_rows) {

		//DISPLAY THE PREVIOUS BUTTON
		echo '<li><a aria-label="Previous"><span aria-hidden="true">«</span></a></li>';

		//FOR LOOP TO CREATE N PAGES DEPENDING ON THE SELECT STATEMENT RESULT
		for ($i=1; $i < $total_pages + 1 ; $i++) {

			//CHECK IF ITERATOR IS EQUAL TO CURRENT PAGE
			if ($i == $page) {
				
				//DISPLAY THE PAGE SELECTOR ON PAGE N AND SET IT TO ACTIVE
				echo "<li class='active'><a href='record.php?year=".$_GET['year']."&status=".$_GET['status']."&page=".$i."'>".$i."</a></li>";
				continue;
			}
				//DISPLAY THE PAGE SELECTOR ON PAGE N
				echo "<li><a href='record.php?year=".$_GET['year']."&status=".$_GET['status']."&page=".$i."'>".$i."</a></li>";
		}

		if ($page == $total_pages) {
			echo '<li><a aria-label="Next"><span aria-hidden="true">»</span></a></li>';
		} else {
			$nextpage = $page + 1;

			echo '<li><a aria-label="Next" href="record.php?year='.$_GET["year"].'&status='.$_GET["status"].'&page='.$nextpage.'"><span aria-hidden="true">»</span></a></li>';
		}			
	}

	//DISPLAY THE CLOSING TAG FOR THE PAGINATION
	echo '</ul></nav>';
}