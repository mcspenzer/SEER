<?php
/**
 * 
 * FILE [seer_forgotPass.inc.php]
 * 
 * MODULE FOR THE FORGOT PASSWORD SUPPORT
 * 
 */

	//DEPENDENCIES FOR EMAIL-VERIFICATION MODULE
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;

	include_once 'seer_database.inc.php';
	require '../vendor/autoload.php';

	//CHECK IF METHOD USED IS 'POST'
	if (isset($_POST['submit'])) {
		$email = $_POST['emailToVerify'];

		//CHECK IF PASSED EMAIL IS NOT EMPTY
		if (!empty($email)) {

			//CHECK IF EMAIL SYNTAX IS VALID
			if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

				//EMAIL PASSED VIA POST
				$email = $_POST['emailToVerify'];

				//QUERY FOR CHECKING IF EMAIL IS EXISTENT
				$sql_query = "SELECT * FROM users WHERE user_email = '$email'";
				
				//RESULT FOR THE QUERY
				$sql_result = mysqli_query($connect, $sql_query);

				//NUMBER OF ROWS AFFECTED BY THE QUERY
				$sql_check = mysqli_num_rows($sql_result);

				//CHECK IF EMAIL PASSED IS EXISTENT IN THE DATABASE
				if ($sql_check == 1) {

					//FETCH THE ACTUAL RECORDS RETURNED BY THE QUERY
					$sql_row = mysqli_fetch_assoc($sql_result);

					//PRIME THE DEFAULT TIMEZONE FOR THE RANDOM HASH
					date_default_timezone_set('Asia/Manila');

					//TIMESTAMP OF THE DATE WHERE THE CODE IS EXECUTED
					$presentDate = date("Y-m-d H:i:s");

					//HASHED TIMESTAMP TO PLACE IN THE DATABASE
					$timestampHash = password_hash($presentDate, PASSWORD_DEFAULT); echo '<br>assigned timestamp hash: '.$timestampHash.'<br>';

					//CHECK IF THE USER ALREADY REQUESTED A PASSWORD RESET EMAIL
					if (empty($sql_row['forgotPW_token'])) {

						//CREATE PHPMAILER INSTANCE
						$mail = new PHPMailer();

						//TRY BLOCK FOR SENDING THE EMAIL
						try {

							/**
							 * 
							 * EMAIL CONFIGURATIONS
							 * 
							 */
							$mail->isSMTP();										//SET PROTOCOL TO BE SMTP
							$mail->SMTPDebug 	= 0;								//VERBOSE DISABLED
							$mail->Host 		= 'smtp.gmail.com';					//SMTP DOMAIN
							$mail->SMTPAuth 	= true;								//ENABLE SMPT AUTHENTICATION
							$mail->Username 	= 'spenzcasuga@gmail.com';			//EMAIL TO BE USED FOR SENDING THE VERIFICATION EMAIL
							$mail->Password 	= 'lifestealer';					//PASSWORD FOR THE EMAIL 
							$mail->SMTPSecure 	= 'tls';							//ENABLE TLS SECURE
							$mail->Port 		= 587;								//PORT TO BE USED BY SMTP

							/**
							 * 
							 * THESE ARE NEEDED FOR ADDITIONAL SUPPORT
							 * FOR SMTP
							 * 
							 */
							$mail->SMTPOptions = array(
									'ssl' => array(
										'verify_peer' 		=> false,
										'verify_peer_name'  => false,
										'allow_self_signed' => true
									)
								);

							//EMAIL RECIPIENTS
							$mail->setFrom('reset@seersystems.com', 'SEERSystems');	//THE SENDER OF THE EMAIL THAT WILL APPEAR TO THE RECIPIENT
							$mail->addAddress($email);								//THE REQUESTING USER'S EMAIL

							//ENABLE HTML FORMAT
							$mail->isHTML(true);

							/**
							 * 
							 * THE BODY OF THE EMAIL
							 * 
							 */
							include_once 'email_body.inc.php';						//INCLUDE THE EMAIL BODY IN HTML FORMAT
							$mail->Subject = 'SEERSystems Password Reset';			//SUBJECT
							$mail->Body = $email_html;								//THE BODY OF THE EMAIL
							$mail->AltBody = $email_plain;							//THE EMAIL BODY IN PLAIN TEXT

							//SEND MAIL
							$mail->send();
							echo'Message Sent';

							//SET THE TIMESTAMP HASH FOR EMAIL REQUEST
							$sql_query = "UPDATE users
											SET forgotPW_token = '$timestampHash',
											forgotPW_request_date = '$presentDate'
										WHERE user_email = '$email'";

							//PLACE TOKEN AND REQUEST DATE TO ASSOCIATED ROW
							mysqli_query($connect, $sql_query);

							//REDIRECT TO FORGOT PASSWORD PAGE - SUCCESS
							header("Location: ../forgot_password.php?forgot=EMAIL_SENT");
							exit();
						} catch (Exception $e) {
							//EMAIL NOT SENT - ERROR
							echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
						}
					} else {
						//THERE IS ALREADY A REQUEST MADE FOR RESETTING THE PASSWORD
						header("Location: ../forgot_password.php?forgot=EXISTING");
						exit();
					}
				} else {
					//THERE IS NO EMAIL MATCH IN THE DATABASE
					header("Location: ../forgot_password.php?forgot=EMAIL_VOID");
					exit();
				}
			} else {
				//EMAIL ENTERED IS INVALID
				header("Location: ../forgot_password.php?forgot=EMAIL_INVALID");
				exit();
			}
		} else {
			//NO EMAIL IS ENTERED
			header("Location: ../forgot_password.php?forgot=EMAIL_NULL");
			exit();
		}
	} else {
		//POST METHOD NOT USED TO GET TO WEBPAGE
		header("Location: ../login.php?forgot=METHOD_ERROR");
		exit();
	}