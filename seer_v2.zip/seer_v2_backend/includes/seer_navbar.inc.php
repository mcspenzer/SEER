<!-- SYSTEM NAVBAR -->

<div id="mainhead">
        <nav class="navbar navbar-default navigation-clean-search">
            <div class="container">
                <div class="navbar-header">
                    <a class="navbar-brand" href="home.php">Seer </a>
                    <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse" id="navcol-1">
                    <ul class="nav navbar-nav">
                        <?php
                            if (basename($_SERVER['PHP_SELF']) == "home.php") {
                                echo '
                                    <li class="active" role="presentation"><a href="home.php" id="btnhome">Home </a></li>
                                    <li role="presentation"><a href="profile.php" id="btnprof">Profile </a></li>
                                    <li role="presentation"><a href="record.php" id="btnrec">Records </a></li>';
                                if ($_SESSION['user_is_adminSession']) {
                                    echo "<li role='presentation'><a href='accounts.php'>Accounts </a></li>";
                                }
                            } elseif (basename($_SERVER['PHP_SELF']) == "profile.php") {
                                echo '
                                    <li role="presentation"><a href="home.php">Home </a></li>
                                    <li class="active" role="presentation"><a href="profile.php" id="btnhome">Profile </a></li>
                                    <li role="presentation"><a href="record.php" id="btnrec">Records </a></li>';
                                if ($_SESSION['user_is_adminSession']) {
                                    echo "<li role='presentation'><a href='accounts.php'>Accounts </a></li>";
                                }
                            } elseif (basename($_SERVER['PHP_SELF']) == "record.php") {
                                echo '
                                    <li role="presentation"><a href="home.php" id="">Home </a></li>
                                    <li role="presentation"><a href="profile.php" id="btnprof">Profile </a></li>
                                    <li class="active" role="presentation"><a href="record.php" id="btnhome">Records </a></li>';
                                if ($_SESSION['user_is_adminSession']) {
                                    echo "<li role='presentation'><a href='accounts.php'>Accounts </a></li>";
                                }
                            } elseif (basename($_SERVER['PHP_SELF']) == "accounts.php") {
                                echo '
                                    <li role="presentation"><a href="home.php" id="">Home </a></li>
                                    <li role="presentation"><a href="profile.php" id="btnprof">Profile </a></li>
                                    <li role="presentation"><a href="record.php" id="btnrec">Records </a></li>';
                                if ($_SESSION['user_is_adminSession']) {
                                    echo '<li class="active" role="presentation"><a href="accounts.php" id="btnhome">Accounts </a></li>';
                                }
                            }
                            
                        ?>
                    </ul>
                    <form class="navbar-form navbar-left" target="_self">
                        <div class="form-group">
                            <label class="control-label" for="search-field">
                                <i class="glyphicon glyphicon-search" style="color:black;"></i>
                            </label>
                            <input class="form-control search-field" type="search" name="search" placeholder="e.g. 2015081526" maxlength="10" minlength="10" id="search-field" style="color:black;">
                        </div>
                    </form>
                    <form method="POST" action="includes/seer_logout.inc.php">
                        <input type="submit" name="logout" class="btn btn-default navbar-btn navbar-right action-button" value="Logout" id="log">
                    </form>
                </div>
            </div>
        </nav>
    </div>