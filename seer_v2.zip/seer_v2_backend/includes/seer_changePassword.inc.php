<?php
/**
 * 
 * FILE [seer_changePassword.inc.php]
 * 
 * MODULE TO SUPPORT PASSWORD CHANGE
 * 
 */
session_start();

//CHECK IF POST METHOD IS USED 
if (isset($_POST['submit'])) {

	//INCLUDE THE NECESSARY ASSETS FOR ACCESSING THE DATABASE
	include 'seer_database.inc.php';

	/**
	 * 
	 * THE ARGUMENTS PASSED VIA THE POST METHOD
	 * 
	 */
	$oldPassword 		= mysqli_real_escape_string($connect, $_POST['pass_old']);						//OLD PASSWORD OF USER ENTERED
	$currentUser		= mysqli_real_escape_string($connect, $_SESSION['user_usernameSession']);		//CURRENT USER
	$newPassword 		= mysqli_real_escape_string($connect, $_POST['pass_new']);						//NEW PASSWORD OF USER ENTERED
	$confirmNewPassword = mysqli_real_escape_string($connect, $_POST['pass_confirm']);					//NEW PASSWORD CONFIRMATION
	$uid 				= mysqli_real_escape_string($connect, $_SESSION['user_idSession']);				//USER IDENTIFICATION

	//SQL STATEMENT FOR SELECTING THE USER RECORD OF THE CURRENT USER
	$sql_query = "SELECT * FROM users WHERE user_username = '$currentUser'";

	//RESULT OF THE SQL STATEMENT
	$sql_result = mysqli_query($connect, $sql_query);

	//ROWS AFFECTED BY THE QUERY
	$sql_row = mysqli_fetch_assoc($sql_result);
	
	//CHECK IF FIELDS PASSED BY THE POST METHOD IS NOT EMPTY
	if (empty($oldPassword) || empty($newPassword) || empty($confirmNewPassword)) {

		//PASSWORD FIELDS ARE EMPTY
		header("Location: ../profile.php?password=NULL");
		exit();
	} else {

		//VARIABLE CONTAINING IF OLD PASSWORD MATCHES THE PASSWORD IN THE DATABASE
		$verifyPassword = password_verify($oldPassword, $sql_row['user_password']);

		//CHECK IF THE OLD PASSWORD ENTERED DOES NOT MATCH THE OLD PASSWORD IN THE DATABASE
		if ($verifyPassword == false) {

			//OLD PASSWORD ENTERED DOES NOT MATCH THE OLD PASSWORD IN THE DATABASE
			header("Location: ../profile.php?password=OLD_PASS_VOID");
			exit();

		//CHECK IF THE OLD PASSWORD ENTERED DOES MATCH THE OLD PASSWORD IN THE DATABASE
		} elseif ($verifyPassword == true) {

			//CHECK IF THE NEW PASSWORD IS EQUAL TO THE NEW PASSWORD
			if ($newPassword == $oldPassword) {

				//THE NEW PASSWORD IS ALSO EQUAL TO THE OLD PASSWORD
				header("Location: ../profile.php?password=OLD_EQ_NEW");
				exit();
			} else {

				//IF THE NEW PASSWORD ENTERED DOES NOT MATCH WITH THE PASSWORD CONFIRMATION
				if ($newPassword != $confirmNewPassword) {

					//NEW PASSWORD ENTERED DOES NOT MATCH
					header("Location: ../profile.php?password=PASSWORD_NOT_EQUAL");
					exit();
				} else {

					//HASH THE NEW PASSWORD ENTERED
					$hashedNewPass = password_hash($newPassword, PASSWORD_DEFAULT);

					//THE SQL QUERY FOR THE PASSWORD CHANGE
					$sql_query = "
					UPDATE users 
						SET user_password = '$hashedNewPass' 
					WHERE user_id = '$uid'";

					//APPLY THE NEW PASSWORD TO THE DATABASE
					mysqli_query($connect, $sql_query);

					//PASSWORD CHANGE SUCCESS
					header("Location: ../profile.php?password=CHANGE_SUCCESS");
					exit();
				}
			}
		}
	}
}