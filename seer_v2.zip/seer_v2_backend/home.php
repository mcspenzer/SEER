<?php
    define('RESTRICTED', true);

    include_once 'includes/seer_head.inc.php';
    include_once 'includes/seer_database.inc.php';
?>

<body>
<?php
    include_once 'includes/seer_navbar.inc.php';
?>
    <div class="form-group" id="mainbod">
        <div class="row" id="heading">
            <div class="col-md-12">
                <h1>Welcome, <?php echo $_SESSION['user_firstSession']."!"; ?></h1>
                <?php 
                    if ($_SESSION['user_is_adminSession']) {
                        echo "<p style='font-size:18px;'>Administrator</p>";
                    } else {
                        echo "<p style='font-size:18px;'>Faculty</p>";
                    }
                ?>
                <p>Current Academic Year: 2017-2018</p>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4 col-md-12">
                <h1>Summary of students</h1>
                <div class="row">
                    <div class="col-lg-6 col-md-12"><a href="records.php?year=1">First Year</a>
                        <?php
                            $sql_query = "SELECT * FROM students WHERE stud_year = '1'";
                            $sql_result = mysqli_query($connect, $sql_query);
                            $sql_number_of_rows = mysqli_num_rows($sql_result);

                            echo "<p>".$sql_number_of_rows."</p>";
                        ?>
                    </div>
                    <div class="col-lg-6 col-md-12"><a href="records.php?year=2">Second Year</a>
                        <?php 
                            $sql_query = "SELECT * FROM students WHERE stud_year = '2'";
                            $sql_result = mysqli_query($connect, $sql_query);
                            $sql_number_of_rows = mysqli_num_rows($sql_result);
                            
                            echo "<p>".$sql_number_of_rows."</p>";
                        ?>
                    </div>
                    <div class="col-lg-6 col-md-12"><a href="records.php?year=3">Third Year</a>
                        <?php 
                            $sql_query = "SELECT * FROM students WHERE stud_year = '3'";
                            $sql_result = mysqli_query($connect, $sql_query);
                            $sql_number_of_rows = mysqli_num_rows($sql_result);
                            
                            echo "<p>".$sql_number_of_rows."</p>";
                        ?>
                    </div>
                    <div class="col-lg-6 col-md-12"><a href="records.php?year=4">Fourth Year</a>
                        <?php 
                            $sql_query = "SELECT * FROM students WHERE stud_year = '4'";
                            $sql_result = mysqli_query($connect, $sql_query);
                            $sql_number_of_rows = mysqli_num_rows($sql_result);
                            
                            echo "<p>".$sql_number_of_rows."</p>";
                        ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-12">
                <h1>Status per student</h1>
                <div class="row">
                    <div class="col-lg-6 col-md-12"><a href="records.php?status=1">Regular </a>
                        <?php
                            $sql_query = "SELECT * FROM students WHERE stud_status = 'R'";
                            $sql_result = mysqli_query($connect, $sql_query);
                            $sql_number_of_rows = mysqli_num_rows($sql_result);
                            
                            echo "<p>".$sql_number_of_rows."</p>";
                        ?>
                    </div>
                    <div class="col-lg-6 col-md-12"><a href="records.php?status=2">Irregular </a>
                        <?php
                            $sql_query = "SELECT * FROM students WHERE stud_status = 'IR'";
                            $sql_result = mysqli_query($connect, $sql_query);
                            $sql_number_of_rows = mysqli_num_rows($sql_result);
                            
                            echo "<p>".$sql_number_of_rows."</p>";
                        ?>
                        </div>
                    <div class="col-lg-6 col-md-12"><a href="records.php?status=3main">Conditional </a>
                        <?php
                            $sql_query = "SELECT * FROM students WHERE stud_status LIKE 'C_'";
                            $sql_result = mysqli_query($connect, $sql_query);
                            $sql_number_of_rows = mysqli_num_rows($sql_result);
                            
                            echo "<p>".$sql_number_of_rows."</p>";
                        ?>
                    </div>
                    <div class="col-lg-6 col-md-12"><a href="records.php?status=4main">Debarred </a>
                        <?php
                            $sql_query = "SELECT * FROM students WHERE stud_status LIKE 'D_'";
                            $sql_result = mysqli_query($connect, $sql_query);
                            $sql_number_of_rows = mysqli_num_rows($sql_result);
                            
                            echo "<p>".$sql_number_of_rows."</p>";
                        ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-12">
                <h1>Total number of students in the Database</h1>
                <?php 
                    $sql_query = "SELECT * FROM students";
                    $sql_result = mysqli_query($connect, $sql_query);
                    $sql_number_of_rows = mysqli_num_rows($sql_result);

                    echo "<h1>".$sql_number_of_rows."</h1>";
                ?>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
    <script src="assets/js/bs-animation.js"></script>
</body>
</html>