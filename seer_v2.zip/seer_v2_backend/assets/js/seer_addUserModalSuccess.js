$(document).ready(function() {
	$(".save-modal").click(function() {
		$("#addmodlog").modal("show");
	}
}