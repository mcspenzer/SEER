<?php
    include_once 'includes/seer_head.inc.php';
?>
<body>
<div class="modal fade" role="dialog" tabindex="-1" id="addstud">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title">Add student record</h4>
            </div>
            <div class="modal-body">
                <form method="POST" action="includes/seer_addStudent.inc.php">
                    <div class="row" id="rowstudn">
                        <div class="col-lg-6 col-md-12">
                            <p>Student Number</p>
                        </div>
                        <div class="col-lg-6 col-md-12"><input type="text" maxlength="10" minlength="10" style="width:177px;" name="stud_no" required></div>
                    </div>
                    <div class="row" id="rowln">
                        <div class="col-lg-6 col-md-12">
                            <p>Last name</p>
                        </div>
                        <div class="col-lg-6 col-md-12"><input type="text" style="width:177px;" name="stud_last" required></div>
                    </div>
                    <div class="row" id="rowfn">
                        <div class="col-lg-6 col-md-12">
                            <p>First name</p>
                        </div>
                        <div class="col-lg-6 col-md-12"><input type="text" style="width:177px;" name="stud_first" required></div>
                    </div>
                    <div class="row" id="rowmi">
                        <div class="col-lg-6 col-md-12">
                            <p>Middle initial</p>
                        </div>
                        <div class="col-lg-6 col-md-12">
                            <input type="text" style="width:177px;" name="stud_MI" required>
                        </div>
                        <div class="col-md-12 form-inline">
                            <div class="form-group">
                                <label >Year level</label>
                                <select class="form-control" name="stud_year" required>
                                    <option value="0">select one</option>
                                    <option value="1">First Year</option>
                                    <option value="2">Second Year</option>
                                    <option value="3">Third Year</option>
                                    <option value="4">Fourth Year</option>
                                    <option value="5">Fifth Year</option>
                                    <option value="6">Sixth Year</option>
                                    <option value="7">Seventh Year</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <hr>
                        <button class="btn btn-default" type="button" data-dismiss="modal">Close</button>
                        <button class="btn btn-primary" type="submit" style="background-color:green;color:white;" name="submit">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php
    include_once 'includes/seer_navbar.inc.php';
?>
<div class="form-group" id="mainbod">
    <div class="row">
        <div class="col-md-12">
            <h1>Records </h1>
        </div>
        <div class="col-lg-12 col-md-12">
            <h4>Search by</h4>
        </div>
        <form method="GET" action="records.php" class="form-inline">
            <div class="col-lg-3 col-md-12">
                <div class="form-group">
                    <label >Status</label>
                    <select  class="form-control" name="status">
                        <?php
                            if (isset($_GET['status'])) {
                                if ($_GET['status'] == "1") {
                                    echo '
                                    <option value="0">Any</option>
                                    <option value="1" selected="selected">Regular</option>
                                    <option value="2">Irregular</option>
                                    <option value="3main">Conditional All</option>
                                    <option value="3a">--Conditional C1</option>
                                    <option value="3b">--Conditional C2</option>
                                    <option value="4main">Debarred All</option>
                                    <option value="4a">--Debarred D1</option>
                                    <option value="4b">--Debarred D2</option>
                                    <option value="4c">--Debarred D3</option>
                                    <option value="4d">--Debarred D4</option>';
                                } elseif ($_GET['status'] == "2") {
                                    echo '
                                    <option value="0">Any</option>
                                    <option value="1">Regular</option>
                                    <option value="2" selected="selected">Irregular</option>
                                    <option value="3main">Conditional All</option>
                                    <option value="3a">--Conditional C1</option>
                                    <option value="3b">--Conditional C2</option>
                                    <option value="4main">Debarred All</option>
                                    <option value="4a">--Debarred D1</option>
                                    <option value="4b">--Debarred D2</option>
                                    <option value="4c">--Debarred D3</option>
                                    <option value="4d">--Debarred D4</option>';
                                } elseif ($_GET['status'] == "3main") {
                                    echo '
                                    <option value="0">Any</option>
                                    <option value="1">Regular</option>
                                    <option value="2">Irregular</option>
                                    <option value="3main" selected="selected" style="font-weight: bold;">Conditional All</option>
                                    <option value="3a">--Conditional C1</option>
                                    <option value="3b">--Conditional C2</option>
                                    <option value="4main">Debarred All</option>
                                    <option value="4a">--Debarred D1</option>
                                    <option value="4b">--Debarred D2</option>
                                    <option value="4c">--Debarred D3</option>
                                    <option value="4d">--Debarred D4</option>';
                                } elseif ($_GET['status'] == "3a") {
                                    echo '
                                    <option value="0">Any</option>
                                    <option value="1">Regular</option>
                                    <option value="2">Irregular</option>
                                    <option value="3main">Conditional All</option>
                                    <option value="3a" selected="selected">--Conditional C1</option>
                                    <option value="3b">--Conditional C2</option>
                                    <option value="4main">Debarred All</option>
                                    <option value="4a">--Debarred D1</option>
                                    <option value="4b">--Debarred D2</option>
                                    <option value="4c">--Debarred D3</option>
                                    <option value="4d">--Debarred D4</option>';
                                } elseif ($_GET['status'] == "3b") {
                                    echo '
                                    <option value="0">Any</option>
                                    <option value="1">Regular</option>
                                    <option value="2">Irregular</option>
                                    <option value="3main">Conditional All</option>
                                    <option value="3a">--Conditional C1</option>
                                    <option value="3b" selected="selected">--Conditional C2</option>
                                    <option value="4main">Debarred All</option>
                                    <option value="4a">--Debarred D1</option>
                                    <option value="4b">--Debarred D2</option>
                                    <option value="4c">--Debarred D3</option>
                                    <option value="4d">--Debarred D4</option>';
                                } elseif ($_GET['status'] == "4main") {
                                    echo '
                                    <option value="0">Any</option>
                                    <option value="1">Regular</option>
                                    <option value="2">Irregular</option>
                                    <option value="3main">Conditional All</option>
                                    <option value="3a">--Conditional C1</option>
                                    <option value="3b">--Conditional C2</option>
                                    <option value="4main" selected="selected" style="font-weight: bold;">Debarred All</option>
                                    <option value="4a">--Debarred D1</option>
                                    <option value="4b">--Debarred D2</option>
                                    <option value="4c">--Debarred D3</option>
                                    <option value="4d">--Debarred D4</option>';
                                } elseif ($_GET['status'] == "4a") {
                                    echo '
                                    <option value="0">Any</option>
                                    <option value="1">Regular</option>
                                    <option value="2">Irregular</option>
                                    <option value="3main">Conditional All</option>
                                    <option value="3a">--Conditional C1</option>
                                    <option value="3b">--Conditional C2</option>
                                    <option value="4main">Debarred All</option>
                                    <option value="4a" selected="selected">--Debarred D1</option>
                                    <option value="4b">--Debarred D2</option>
                                    <option value="4c">--Debarred D3</option>
                                    <option value="4d">--Debarred D4</option>';
                                } elseif ($_GET['status'] == "4b") {
                                    echo '
                                    <option value="0">Any</option>
                                    <option value="1">Regular</option>
                                    <option value="2">Irregular</option>
                                    <option value="3main">Conditional All</option>
                                    <option value="3a">--Conditional C1</option>
                                    <option value="3b">--Conditional C2</option>
                                    <option value="4main">Debarred All</option>
                                    <option value="4a">--Debarred D1</option>
                                    <option value="4b" selected="selected">--Debarred D2</option>
                                    <option value="4c">--Debarred D3</option>
                                    <option value="4d">--Debarred D4</option>';
                                } elseif ($_GET['status'] == "4c") {
                                    echo '
                                    <option value="0">Any</option>
                                    <option value="1">Regular</option>
                                    <option value="2">Irregular</option>
                                    <option value="3main">Conditional All</option>
                                    <option value="3a">--Conditional C1</option>
                                    <option value="3b">--Conditional C2</option>
                                    <option value="4main">Debarred All</option>
                                    <option value="4a">--Debarred D1</option>
                                    <option value="4b">--Debarred D2</option>
                                    <option value="4c" selected="selected">--Debarred D3</option>
                                    <option value="4d">--Debarred D4</option>';
                                } elseif ($_GET['status'] == "4d") {
                                    echo '
                                    <option value="0">Any</option>
                                    <option value="1">Regular</option>
                                    <option value="2">Irregular</option>
                                    <option value="3main">Conditional All</option>
                                    <option value="3a">--Conditional C1</option>
                                    <option value="3b">--Conditional C2</option>
                                    <option value="4main">Debarred All</option>
                                    <option value="4a">--Debarred D1</option>
                                    <option value="4b">--Debarred D2</option>
                                    <option value="4c">--Debarred D3</option>
                                    <option value="4d" selected="selected">--Debarred D4</option>';
                                } else {
                                    echo '
                                    <option value="0">Any</option>
                                    <option value="1">Regular</option>
                                    <option value="2">Irregular</option>
                                    <option value="3main">Conditional All</option>
                                    <option value="3a">--Conditional C1</option>
                                    <option value="3b">--Conditional C2</option>
                                    <option value="4main">Debarred All</option>
                                    <option value="4a">--Debarred D1</option>
                                    <option value="4b">--Debarred D2</option>
                                    <option value="4c">--Debarred D3</option>
                                    <option value="4d">--Debarred D4</option>';
                                }
                            } else {
                                echo '
                                <option value="0">Any</option>
                                <option value="1">Regular</option>
                                <option value="2">Irregular</option>
                                <option value="3main">Conditional All</option>
                                <option value="3a">--Conditional C1</option>
                                <option value="3b">--Conditional C2</option>
                                <option value="4main">Debarred All</option>
                                <option value="4a">--Debarred D1</option>
                                <option value="4b">--Debarred D2</option>
                                <option value="4c">--Debarred D3</option>
                                <option value="4d">--Debarred D4</option>';
                            }
                        ?>
                    </select>
                </div>
            </div>
            <div class="col-lg-2 col-md-12" style="margin-left: -130px;">
                <div class="form-group">
                    <label >Year</label>
                     <select  class="form-control" name="year">
                        <option value="0">Any</option>
                        <option value="1">1st Year</option>
                        <option value="2">2nd Year</option>
                        <option value="3">3rd Year</option>
                        <option value="4">4th Year</option>
                        <option value="5">5th Year</option>
                        <option value="6">6th Year</option>
                        <option value="7">7th Year</option>
                      </select>
                </div>
            </div>
            <div class="radio col-lg-3 col-md-12">
                <label style="margin-left: -30px;"><input type="radio" name="order" value="ascending">Ascending</label><br>
                <label style="margin-left: -30px;"><input type="radio" name="order" value="descending">Descending</label>
            </div>
            <div class="col-lg-1 col-md-12"><button class="btn btn-default" type="submit" id="rgo" style="background-color:green;color:white; margin-left: -260px;">Go </button></div>
        </form>
        <div class="col-md-12">
            <hr>
        </div>
    </div>
    <table id="example" class="table table-striped table-bordered" cellspacing="0" width="50%">
        <thead>
            <tr>
                <th>Student Number</th>
                <th>Last Name</th>
                <th>First Name</th>
                <th>Middle Initial</th>
                <th>Year</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
                include_once 'includes/seer_database.inc.php';

                $sql_query = "SELECT * FROM students";

                if (isset($_GET['status']) || isset($_GET['year']) || isset($_GET['order'])) {
                    if (isset($_GET['status']) && isset($_GET['year']) && isset($_GET['order'])) {
                        if ($_GET['status'] != '0') {
                            if ($_GET['status'] == '1') {
                                $sql_query .= " WHERE stud_status = 'R'";
                            } elseif ($_GET['status'] == '2') {
                                $sql_query .= " WHERE stud_status = 'IR'";
                            } elseif ($_GET['status'] == '3a') {
                                $sql_query .= " WHERE stud_status = 'C1'";
                            } elseif ($_GET['status'] == '3b') {
                                $sql_query .= " WHERE stud_status = 'C2'";
                            } elseif ($_GET['status'] == '4a') {
                                $sql_query .= " WHERE stud_status = 'D1'";
                            } elseif ($_GET['status'] == '4b') {
                                $sql_query .= " WHERE stud_status = 'D2'";
                            } elseif ($_GET['status'] == '4c') {
                                $sql_query .= " WHERE stud_status = 'D3'";
                            } elseif ($_GET['status'] == '4d') {
                                $sql_query .= " WHERE stud_status = 'D4'";
                            } elseif ($_GET['status'] == '3main') {
                                $sql_query .= " WHERE stud_status LIKE 'C_'";
                            } elseif ($_GET['status'] == '4main') {
                                $sql_query .= " WHERE stud_status LIKE 'D_'";
                            }
                        }
    
                        if ($_GET['year'] != '0') {
                            if ($_GET['status'] != '0') {
                                $sql_query .= " AND";
                            } else {
                                $sql_query .= " WHERE";
                            }
                            
                            if ($_GET['year'] == '1') {
                                $sql_query .= " stud_year = '1'";
                            } elseif ($_GET['year'] == '2') {
                                $sql_query .= " stud_year = '2'";
                            } elseif ($_GET['year'] == '3') {
                                $sql_query .= " stud_year = '3'";
                            } elseif ($_GET['year'] == '4') {
                                $sql_query .= " stud_year = '4'";
                            } elseif ($_GET['year'] == '5') {
                                $sql_query .= " stud_year = '5'";
                            } elseif ($_GET['year'] == '6') {
                                $sql_query .= " stud_year = '6'";
                            } elseif ($_GET['year'] == '7') {
                                $sql_query .= " stud_year = '7'";
                            }
                        }
    
                        if (isset($_GET['order'])) {
                            if ($_GET['order'] == 'ascending') {
                                $sql_query .= " ORDER BY stud_number"; 
                            } elseif ($_GET['order'] == 'descending') {
                                $sql_query .= " ORDER BY stud_number DESC"; 
                            }
                        }
                    } elseif (empty($_GET['status']) && isset($_GET['year']) && empty($_GET['order'])) {
                        if ($_GET['year'] == '1') {
                            $sql_query .= " WHERE stud_year = '1'";
                        } elseif ($_GET['year'] == '2') {
                            $sql_query .= " WHERE stud_year = '2'";
                        } elseif ($_GET['year'] == '3') {
                            $sql_query .= " WHERE stud_year = '3'";
                        } elseif ($_GET['year'] == '4') {
                            $sql_query .= " WHERE stud_year = '4'";
                        } else {
                            header("Location: records.php?=GET_ERROR");
                        }
                    } elseif (isset($_GET['status']) && empty($_GET['year']) && empty($_GET['order'])) {
                        if ($_GET['status'] == '1') {
                            $sql_query .= " WHERE stud_status = 'R'";
                        } elseif ($_GET['status'] == '2') {
                            $sql_query .= " WHERE stud_status = 'IR'";
                        } elseif ($_GET['status'] == '3a') {
                            $sql_query .= " WHERE stud_status = 'C1'";
                        } elseif ($_GET['status'] == '3b') {
                            $sql_query .= " WHERE stud_status = 'C2'";
                        } elseif ($_GET['status'] == '4a') {
                            $sql_query .= " WHERE stud_status = 'D1'";
                        } elseif ($_GET['status'] == '4b') {
                            $sql_query .= " WHERE stud_status = 'D2'";
                        } elseif ($_GET['status'] == '4c') {
                            $sql_query .= " WHERE stud_status = 'D3'";
                        } elseif ($_GET['status'] == '4d') {
                            $sql_query .= " WHERE stud_status = 'D4'";
                        } elseif ($_GET['status'] == '3main') {
                            $sql_query .= " WHERE stud_status LIKE 'C_'";
                        } elseif ($_GET['status'] == '4main') {
                            $sql_query .= " WHERE stud_status LIKE 'D_'";
                        }
                    }
                }

                echo "$sql_query";

                $sql_result = mysqli_query($connect, $sql_query);

                while ($row_result = mysqli_fetch_assoc($sql_result)) {
                    echo 
                    "<tr>
                        <td>".$row_result['stud_number']."</td>
                        <td>".$row_result['stud_last']."</td>
                        <td>".$row_result['stud_first']."</td>
                        <td>".$row_result['stud_MI']."</td>";

                    switch ($row_result['stud_year']) {
                        case '1':
                            echo "<td>First Year</td>";
                            break;
                        case '2':
                            echo "<td>Second Year</td>";
                            break;
                        case '3':
                            echo "<td>Third Year</td>";
                            break;
                        case '4':
                            echo "<td>Fourth Year</td>";
                            break;
                        case '5':
                            echo "<td>Fifth Year</td>";
                            break;
                        case '6':
                            echo "<td>Sixth Year</td>";
                            break;
                        case '7':
                            echo "<td>Seventh Year</td>";
                            break;
                        default:
                            echo "<td>Not Set</td>";
                            break;
                    }

                    switch ($row_result['stud_status']) {
                        case 'NC':
                            echo "<td>Not calculated</td></tr>";
                            break;
                        case 'R':
                            echo "<td>Regular</td></tr>";
                            break;
                        case 'IR':
                            echo "<td>Irregular</td></tr>";
                            break;
                        case 'C1':
                            echo "<td>Conditional(1)</td></tr>";
                            break;
                        case 'C2':
                            echo "<td>Conditional(2)</td></tr>";
                            break;
                        case 'D1':
                            echo "<td>Debarred(1)</td></tr>";
                            break;
                        case 'D2':
                            echo "<td>Debarred(2)</td></tr>";
                            break;
                        case 'D3':
                            echo "<td>Debarred(3)</td></tr>";
                            break;
                        case 'D4':
                            echo "<td>Debarred(4)</td></tr>";
                            break;
                        default:
                            break;
                    }
                }
            ?>
        </tbody>
    </table>
    <footer>
        <hr>
        <label class="control-label">Add student record</label>
        <a class="btn btn-default" role="button" href="#" style="background-color:green;color:white;margin:10px;" data-toggle="modal" data-target="#addstud">Add </a>
    </footer>
</div>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
<script src="assets/js/bs-animation.js"></script>
</body>
</html>