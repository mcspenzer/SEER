<?php
    define( 'RESTRICTED', true );

    include_once 'includes/seer_head.inc.php';
    include_once 'includes/seer_database.inc.php';
?>

<body>
<div class="modal fade" role="dialog" tabindex="-1" id="modmod">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Modify user</h4>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to modify FN MI LN's account?</p>
                <p>If yes, please enter your password below:</p><label>Enter password</label><input type="password" style="margin:10px;"></div>
            <div class="modal-footer"><button class="btn btn-default" type="button" data-dismiss="modal">Close</button><button class="btn btn-primary" type="button" style="background-color:green;" data-toggle="modal" data-target="#modmodlog">Save</button></div>
        </div>
    </div>
</div>
<div class="modal fade" role="dialog" tabindex="-1" id="modmodlog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Successfully modified</h4>
            </div>
            <div class="modal-body">
                <p>You have successfully modified FN MI LN's account</p>
                <p>mm/dd/yyyy at h:mm am/pm</p>
            </div>
            <div class="modal-footer"><button class="btn btn-default" type="button" data-dismiss="modal">Close</button><a class="btn btn-primary" role="button" href="accounts.html" style="background-color:green;">Save</a></div>
        </div>
    </div>
</div>
<div class="modal fade" role="dialog" tabindex="-1" id="delmod">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Delete user</h4>
            </div>
            <div class="modal-body">
                <?php 
                    $sql_query = "SELECT * FROM users WHERE user_username = '"."'";
                ?>
                <p>Are you sure you want to delete FN MI LN's account?</p>
                <p>If yes, please enter your password below</p>
                <label>Enter your password:</label>
                <input type="password" style="margin:10px;">
            </div>
            <div class="modal-footer"><button class="btn btn-default" type="button" data-dismiss="modal">Close</button><button class="btn btn-primary" type="button" style="background-color:green;" data-toggle="modal" data-target="#delmodlog">Save</button></div>
        </div>
    </div>
</div>
<div class="modal fade" role="dialog" tabindex="-1" id="delmodlog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Successfully deleted</h4>
            </div>
            <div class="modal-body">
                <p>You have successfully deleted FN MI LN's account.</p>
                <p>mm/dd/yyyy at h:mm</p>
            </div>
            <div class="modal-footer"><button class="btn btn-default" type="button" data-dismiss="modal">Close</button><a class="btn btn-primary" role="button" href="accounts.html" style="background-color:green;">Save</a></div>
        </div>
    </div>
</div>
<div class="modal fade" role="dialog" tabindex="-1" id="addmod">
    <form method="POST" action="includes/seer_addUser.inc.php">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <h4 class="modal-title">Add user</h4>
                </div>
                <div class="modal-body">
                    <div class="row" id="lnrow">
                        <div class="col-md-6"><p>Last name</p></div>
                        <div class="col-md-6"><input type="text" required="" placeholder="e.g. Dela Cruz" maxlength="20" style="width:250px;" name="add_last"></div>
                    </div>
                    <div class="row" id="fnrow">
                        <div class="col-md-6"><p>First name</p></div>
                        <div class="col-md-6"><input type="text" required="" placeholder="e.g. Juan" maxlength="20" style="width:250px;" name="add_first"></div>
                    </div>
                    <div class="row" id="mirow">
                        <div class="col-md-6"><p>Middle initial</p></div>
                        <div class="col-md-6"><input type="text" required="" placeholder="e.g. A" maxlength="1" minlength="1" style="width:250px;" name="add_MI"></div>
                    </div>
                    <div class="row" id="unrow">
                        <div class="col-md-6"><p>Username</p></div>
                        <div class="col-md-6"><input type="text" required="" placeholder="e.g. delacruzj123" maxlength="50" minlength="5" style="width:250px;" name="add_username"></div>
                    </div>
                    <div class="row" id="pwrow">
                        <div class="col-md-6"><p>Password</p></div>
                        <div class="col-md-6"><input type="password" style="width:250px;" name="add_password"></div>
                    </div>
                    <div class="row" id="cpwrow">
                        <div class="col-md-6"><p>Confirm Password</p></div>
                        <div class="col-md-6"><input type="password" style="width:250px;" name="add_passwordConfirm"></div>
                    </div>
                    <div class="row" id="emailrow">
                        <div class="col-md-6"><p>E-mail </p></div>
                        <div class="col-md-6"><input type="text" required="" placeholder="e.g. delacruzjuan@gmail.com" maxlength="50" minlength="5" style="width:250px;" name="add_email"></div>
                    </div>
                    <div class="row" id="cemailrow">
                        <div class="col-md-6"><p>Confirm e-mail</p></div>
                        <div class="col-md-6"><input type="text" required="" placeholder="e.g. delacruzjuan@gmail.com" maxlength="50" minlength="5" style="width:250px;" name="add_emailConfirm"></div>
                    </div>
                    <div class="row" id="accttyperow">
                        <div class="col-md-6">
                            <form class="form-inline">
                                <div class="form-group">
                                    <label >Account Type</label>
                                    <select  class="form-control" name="add_accountType" required="">
                                        <option>Select One</option>
                                        <option value="Administrator">Administrator</option>
                                        <option value="Faculty">Faculty</option>
                                    </select>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-default adduser-modal" type="button" data-dismiss="modal">Close</button>
                    <button type="submit" name="submit" class="btn btn-primary adduser-modal" style="color:white;background-color:green;">Save</button>
                </div>
            </div>
        </div>
    </form>
</div>
<div class="modal fade" role="dialog" tabindex="-1" id="addmodlog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Successfully added a user!</h4>
            </div>
            <div class="modal-body">
                <p>FN MI LN has successfully created user FN MI LN</p>
                <p>mm/dd/yyyy at h:mm am/pm</p>
            </div>
            <div class="modal-footer">
                <button class="btn btn-default" type="button" data-dismiss="modal">Close</button>
                <a class="btn btn-primary" role="button" href="#addmodlog" style="background-color:green;" data-toggle="modal" data-target="#addmodlog">Save</a>
            </div>
        </div>
    </div>
</div>

<?php
    include_once 'includes/seer_navbar.inc.php';
?>

<div class="form-group" id="mainbod">
    <div class="row">
        <div class="col-md-12">
            <h1>Accounts </h1>
            <table id="accounts" class="table table-striped table-bordered" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th>Select</th>
                        <th>Last name</th>
                        <th>First name</th>
                        <th>Middle Initial</th>
                        <th>Username</th>
                        <th>Account Type</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $uid_for_session = $_SESSION['user_idSession'];
                        $sql_query = "SELECT * FROM users WHERE user_id != '$uid_for_session'";
                        $sql_result = mysqli_query($connect, $sql_query);

                        while ($row_result = mysqli_fetch_assoc($sql_result)) {
                            echo 
                                "<tr>
                                    <td><input type='radio' value='".$row_result['user_username']."' name='select'>
                                    <td>",$row_result['user_last']."</td>".
                                    "<td>",$row_result['user_first']."</td>".
                                    "<td>",$row_result['user_MI']."</td>".
                                    "<td>",$row_result['user_username']."</td>";

                            if ($row_result['user_is_admin'] == 1) {
                                echo "<td>Administrator</td></tr>";
                            } elseif ($row_result['user_is_admin'] == 0) {
                                echo "<td>Faculty</td></tr>";
                            }
                        }
                    ?>
                </tbody>
            </table>
            <hr>
            <div class="row" id="btnrow">
                <div class="col-md-1" id="logs">
                    <button class="btn btn-default" type="button">Logs</button>
                </div>
                <div class="col-md-1 col-md-offset-7" id="mod">
                    <button class="btn btn-default" type="button" style="color:white;background-color:green;" data-toggle="modal" data-target="#modmod">Modify</button>
                </div>
                <div class="col-md-1" id="del">
                    <button class="btn btn-default" type="button" data-toggle="modal" data-target="#delmod">Delete</button>
                </div>
                <div class="col-md-1" id="add">
                    <button class="btn btn-default" type="button" style="background-color:green;color:white;" data-toggle="modal" data-target="#addmod">Add</button>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
<script src="assets/js/bs-animation.js"></script>
<script type="text/javascript" src="assets/js/seer_addUserModalSuccess.js"></script>
<script type="text/javascript" src="assets/js/jquery-3.3.1.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        var radioValue = $("input[name=select]:checked").val();

        if (typeof(Storage) !== "undefined") {
            sessionStorage.setItem("radioVal", radiovalue);
        } else {
            
        }
    });
</script>
</body>
</html>