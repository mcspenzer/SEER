<?php
    include_once 'includes/seer_database.inc.php';

    if (isset($_GET['verify']) && isset($_GET['email'])) {
        session_start();
        $get_email = $_GET['email'];
        $sql_query = "SELECT * FROM users WHERE user_email = '$get_email'";
        $sql_result = mysqli_query($connect, $sql_query);
        $sql_check = mysqli_num_rows($sql_result);

        if ($sql_check == 1) {
            $row = mysqli_fetch_assoc($sql_result);

            if (!empty($row['forgotPW_token'])) {
                $forgotPW_tokenDB = $row['forgotPW_token'];

                if ($forgotPW_tokenDB == $_GET['verify']) {
                    $_SESSION['email'] = $get_email;
                    // include_once 'reset_password_html.php';
                    header("Location: reset_password_html.php");
                    exit();
                } else {
                    header("Location: login.php?reset=TOKEN_MISMATCH");
                    exit();
                }
            } else {
                header("Location: login.php?reset=NO_TOKEN");
                exit();
            }
        }
    } else {
        header("Location: login.php?reset=INVALID_LINK");
        exit();
    }
?>